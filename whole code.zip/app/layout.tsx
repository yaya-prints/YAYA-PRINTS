"use client";

import { Inter } from "next/font/google";
import "./globals.css";
import Link from "next/link";
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // --- THEME STATE ---
  const [isDarkMode, setIsDarkMode] = useState(true);

  // --- ROUTE CHECKING (Hides menu on these pages) ---
  const isMockupPage = pathname === '/mockup-creator' || pathname === '/mockup-v2';
  const isShopFloorPage = pathname === '/shop-floor';
  const isPortalPage = pathname?.startsWith('/portal') ?? false;

  // --- THEME: read saved preference on mount ---
  useEffect(() => {
    const savedTheme = localStorage.getItem('yaya-theme');
    if (savedTheme === 'light') setIsDarkMode(false);
  }, []);

  // --- THEME: sync <html class="dark"> whenever isDarkMode changes ---
  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDarkMode]);

  // --- THEME: listen for changes triggered on other pages ---
  useEffect(() => {
    const onThemeChange = () => {
      const t = localStorage.getItem('yaya-theme');
      setIsDarkMode(t !== 'light');
    };
    window.addEventListener('themeChange', onThemeChange);
    return () => window.removeEventListener('themeChange', onThemeChange);
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('yaya-theme', newTheme ? 'dark' : 'light');
    window.dispatchEvent(new Event('themeChange'));
  };

  // --- REUSABLE NAV BUTTON STYLES ---
  const btnBase = "px-4 py-2 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap shadow-sm active:scale-95";

  // --- ACTIVE ROUTE HELPER ---
  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname === href || (pathname?.startsWith(`${href}/`) ?? false);
  };

  // --- NAV LINKS CONFIG ---
  const navGroups: { links: { href: string; label: string; colors: string }[] }[] = [
    {
      links: [
        { href: '/quotes',     label: 'Quotes',          colors: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-400 border border-blue-200 dark:border-blue-500/30 hover:bg-blue-200 dark:hover:bg-blue-500/30' },
        { href: '/jobs',       label: 'Production Board',colors: 'bg-orange-100 text-orange-700 dark:bg-orange-500/20 dark:text-orange-400 border border-orange-200 dark:border-orange-500/30 hover:bg-orange-200 dark:hover:bg-orange-500/30' },
        { href: '/purchasing', label: 'Purchasing',      colors: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400 border border-amber-200 dark:border-amber-500/30 hover:bg-amber-200 dark:hover:bg-amber-500/30' },
        { href: '/todos',      label: 'To-Do List',      colors: 'bg-purple-100 text-purple-700 dark:bg-purple-500/20 dark:text-purple-400 border border-purple-200 dark:border-purple-500/30 hover:bg-purple-200 dark:hover:bg-purple-500/30' },
        { href: '/my-day',     label: 'My Day',          colors: 'bg-pink-100 text-pink-700 dark:bg-pink-500/20 dark:text-pink-400 border border-pink-200 dark:border-pink-500/30 hover:bg-pink-200 dark:hover:bg-pink-500/30' },
        { href: '/invoices',   label: 'Invoices',        colors: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30 hover:bg-emerald-200 dark:hover:bg-emerald-500/30' },
        { href: '/print',      label: 'Print Center',    colors: 'bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-400 border border-rose-200 dark:border-rose-500/30 hover:bg-rose-200 dark:hover:bg-rose-500/30' },
      ],
    },
    {
      links: [
        { href: '/prospector', label: 'Prospector', colors: 'bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-500/20 dark:text-fuchsia-400 border border-fuchsia-200 dark:border-fuchsia-500/30 hover:bg-fuchsia-200 dark:hover:bg-fuchsia-500/30' },
        { href: '/customers',  label: 'CRM',        colors: 'bg-teal-100 text-teal-700 dark:bg-teal-500/20 dark:text-teal-400 border border-teal-200 dark:border-teal-500/30 hover:bg-teal-200 dark:hover:bg-teal-500/30' },
      ],
    },
    {
      links: [
        { href: '/mockup-v2',  label: 'Mockup Engine', colors: 'bg-sky-100 text-sky-700 dark:bg-sky-500/20 dark:text-sky-400 border border-sky-200 dark:border-sky-500/30 hover:bg-sky-200 dark:hover:bg-sky-500/30' },
        { href: '/shop-floor', label: 'Shop Floor',    colors: 'bg-emerald-600 text-white hover:bg-emerald-500 border border-emerald-700 shadow-md' },
      ],
    },
  ];

  return (
    <html lang="en" className={isDarkMode ? "dark" : ""}>
      <body className={`${inter.className} min-h-screen bg-slate-50 dark:bg-[#0f1115] text-slate-900 dark:text-slate-200 overflow-x-hidden transition-colors duration-300`}>

        {/* TOP NAVIGATION BAR */}
        {!isMockupPage && !isShopFloorPage && !isPortalPage && (
          <nav className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 p-3 shadow-sm dark:shadow-md relative z-50 transition-colors duration-300">
            <div className="max-w-[1600px] mx-auto flex items-center justify-between w-full">

              {/* Colorful Menu Buttons */}
              <div className="flex gap-2.5 overflow-x-auto w-full justify-start no-scrollbar items-center py-1 pr-4">

                <Link
                  href="/"
                  className={`${btnBase} bg-slate-800 text-white dark:bg-white dark:text-black hover:opacity-80 ${isActive('/') ? 'ring-2 ring-sky-400 dark:ring-sky-500' : ''}`}
                >
                  🏠 Home
                </Link>

                {navGroups.map((group, gIdx) => (
                  <div key={gIdx} className="flex gap-2.5 items-center">
                    <div className="h-5 w-px bg-slate-200 dark:bg-slate-700 mx-1 shrink-0" aria-hidden="true"></div>
                    {group.links.map(link => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className={`${btnBase} ${link.colors} ${isActive(link.href) ? 'ring-2 ring-sky-400 dark:ring-sky-500' : ''}`}
                      >
                        {link.label}
                      </Link>
                    ))}
                  </div>
                ))}

              </div>

              {/* Utilities (Theme) */}
              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700 shrink-0">
                <button
                  onClick={toggleTheme}
                  className="text-xl transition-transform hover:scale-110 flex items-center justify-center w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800"
                  title="Toggle Theme"
                  aria-label="Toggle theme"
                >
                  {isDarkMode ? '☀️' : '🌙'}
                </button>
              </div>

            </div>
          </nav>
        )}

        {/* MAIN PAGE CONTENT */}
        <main>{children}</main>
      </body>
    </html>
  );
}
