"use client";

import { useState, useEffect, useRef, ReactNode } from "react";
import { supabase } from "@/lib/supabase";
import { useParams, useRouter } from "next/navigation";

// --- DYNAMIC COLOR ENGINE ---
const getColorHex = (colorName: string): string => {
  if (!colorName) return "#CD7F32";
  const lower = colorName.toLowerCase().trim();
  const colorMap: { [key: string]: string } = {
    black: "#0f1115", white: "#94a3b8", navy: "#1e3a8a", red: "#dc2626", royal: "#2563eb", "royal blue": "#2563eb",
    grey: "#6b7280", gray: "#6b7280", "heather grey": "#9ca3af", "sport grey": "#9ca3af", charcoal: "#3f3f46",
    "nardo grey": "#686a6c", green: "#16a34a", "kelly green": "#16a34a", "forest green": "#14532d",
    yellow: "#ca8a04", gold: "#b45309", orange: "#ea580c", purple: "#7e22ce", pink: "#db2777",
    maroon: "#7f1d1d", burgundy: "#7f1d1d", brown: "#78350f", tan: "#d2b48c", sand: "#d2b48c",
    cream: "#d1d5db", teal: "#0d9488", cyan: "#0891b2", blue: "#3b82f6", olive: "#4d7c0f"
  };
  if (colorMap[lower]) return colorMap[lower];
  for (const key in colorMap) { if (lower.includes(key)) return colorMap[key]; }
  return "#CD7F32";
};

// --- DESCRIPTION PARSER: Splits "Tee (Double Sided)" into { name, sides } ---
const parseDescription = (raw: string): { name: string; sides: string | null } => {
  if (!raw) return { name: "", sides: null };
  const match = raw.match(/^(.*?)\s*\((Single Sided|Double Sided|Front Only|Back Only|Front \+ Back|Sleeves|All Over)\)\s*$/i);
  if (match) return { name: match[1].trim(), sides: match[2].trim() };
  return { name: raw, sides: null };
};

// --- DETECT IF AN ITEM IS NON-APPAREL (Print Media / Service / Misc) ---
const isGeneralItem = (item: any): boolean => {
  return !item.quote_item_variants || item.quote_item_variants.length === 0;
};

// --- DYNAMIC GARMENT ICONS ---
const renderGarmentIcon = (description: string, colorHex: string): ReactNode => {
  if (!description) return <span className="w-5 h-5 mr-2 shrink-0"></span>;
  const desc = description.toLowerCase();
  const classes = "w-5 h-5 mr-2 shrink-0 mt-0.5";

  if (desc.includes("hoodie") || desc.includes("hooded")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <path d="M18 9l3 3-2 2-1-2v10H6V12l-1 2-2-2 3-3" /><path d="M8 9V5c0-2.5 1.5-4 4-4s4 1.5 4 4v4" /><path d="M10 9v3" /><path d="M14 9v3" /><path d="M7.5 15h9l1 5H6.5l1-5z" />
      </svg>
    );
  }
  if (desc.includes("polo") || desc.includes("collared")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <path d="M18 7l3 3-2 2-1-2v12H6V10l-1 2-2-2 3-3" /><path d="M9 7l3 4 3-4" /><path d="M12 7v6" /><circle cx="12" cy="10" r="0.5" fill={colorHex}/>
      </svg>
    );
  }
  if (desc.includes("hat") || desc.includes("cap") || desc.includes("beanie")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <path d="M4 15v-2a8 8 0 0 1 16 0v2" /><path d="M2 15h15c2 0 4 1 4 2s-2 2-4 2H2v-4z" /><circle cx="12" cy="4" r="1.5" /><path d="M12 5.5v7.5" />
      </svg>
    );
  }
  if (desc.includes("long sleeve") || desc.includes("longsleeve")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <path d="M17 6L22 18l-3 1-2-9v12H7V12L5 19l-3-1L7 6" /><path d="M8 6c0 2 2 3 4 3s4-1 4-3" />
      </svg>
    );
  }
  if (desc.includes("jacket") || desc.includes("zip")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <path d="M18 9l3 4-2 2-1-3v10H6V12l-1 3-2-2 3-4" /><path d="M9 9V5l3 3 3-3v4" /><path d="M12 8v14" /><path d="M7 16h3" /><path d="M14 16h3" />
      </svg>
    );
  }
  // PRINT MEDIA / GENERIC ICON
  if (desc.includes("dtf") || desc.includes("transfer") || desc.includes("print") || desc.includes("vinyl") || desc.includes("decal") || desc.includes("sticker")) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
        <rect x="3" y="4" width="18" height="14" rx="2" /><path d="M7 8h10" /><path d="M7 12h6" /><path d="M3 18l4-4 3 3 4-5 7 6" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke={colorHex} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={classes}>
      <path d="M18 7l3 3-2 2-1-2v12H6V10l-1 2-2-2 3-3" /><path d="M8 7c0 2 1.5 3 4 3s4-1 4-3" />
    </svg>
  );
};

const QUOTE_VALIDITY_DAYS = 14;

export default function ProfessionalQuotePage() {
  const params = useParams();
  const router = useRouter();
  const [quote, setQuote] = useState<any>(null);

  const canvasRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [canvasHeight, setCanvasHeight] = useState(1122);

  // --- NEW STATES ---
  const [includeHst, setIncludeHst] = useState(false); // OFF BY DEFAULT
  const [depositPct, setDepositPct] = useState(50);
  const [notes, setNotes] = useState("");
  const [showNotes, setShowNotes] = useState(false);
  const [acceptanceStatus, setAcceptanceStatus] = useState<"pending" | "accepted" | "declined">("pending");
  const [signatureName, setSignatureName] = useState("");
  const [signatureDate, setSignatureDate] = useState("");
  const [showSignatureModal, setShowSignatureModal] = useState(false);

  useEffect(() => {
    if (!params?.id) return;

    async function fetchQuote() {
      const { data, error } = await supabase
        .from("quotes")
        .select(`
          *,
          customers (*),
          jobs (job_number),
          quote_items (
            *,
            quote_item_variants (*)
          )
        `)
        .eq("id", params.id)
        .single();

      if (data) setQuote(data);
      if (error) console.error("Quote Fetch Error:", error);
    }

    fetchQuote();
  }, [params]);

  // --- LOCAL PERSISTENCE FOR NOTES + ACCEPTANCE + HST ---
  useEffect(() => {
    if (!params?.id) return;
    const id = String(params.id);
    try {
      const savedNotes = localStorage.getItem(`quote-notes-${id}`);
      if (savedNotes) setNotes(savedNotes);
      const savedAcceptance = localStorage.getItem(`quote-acceptance-${id}`);
      if (savedAcceptance) {
        const parsed = JSON.parse(savedAcceptance);
        setAcceptanceStatus(parsed.status || "pending");
        setSignatureName(parsed.name || "");
        setSignatureDate(parsed.date || "");
      }
      const savedHst = localStorage.getItem(`quote-hst-${id}`);
      if (savedHst !== null) setIncludeHst(savedHst === "true");
    } catch (e) {
      console.error("LocalStorage read failed:", e);
    }
  }, [params]);

  useEffect(() => {
    if (!params?.id) return;
    try { localStorage.setItem(`quote-notes-${String(params.id)}`, notes); } catch {}
  }, [notes, params]);

  useEffect(() => {
    if (!params?.id) return;
    try { localStorage.setItem(`quote-hst-${String(params.id)}`, String(includeHst)); } catch {}
  }, [includeHst, params]);

  useEffect(() => {
    const updateScale = () => {
      if (typeof window !== 'undefined') {
        const screenWidth = window.innerWidth;
        if (screenWidth < 820) setScale((screenWidth - 20) / 794);
        else setScale(1);
      }
    };

    updateScale();
    window.addEventListener('resize', updateScale);

    const observer = new ResizeObserver((entries) => {
      for (let entry of entries) setCanvasHeight(entry.contentRect.height);
    });

    if (canvasRef.current) observer.observe(canvasRef.current);

    return () => {
      window.removeEventListener('resize', updateScale);
      observer.disconnect();
    };
  }, [quote]);

  if (!quote) return <div className="p-10 text-white bg-[#0f1115] flex justify-center items-center h-screen font-black uppercase tracking-widest">Generating Quote...</div>;

  // --- FINANCIAL MATH ---
  const subtotal = quote.total_amount || 0;
  const tax = includeHst ? subtotal * 0.13 : 0;
  const grandTotal = subtotal + tax;
  const deposit = grandTotal * (depositPct / 100);

  const totalSavings = quote.quote_items?.reduce((itemSum: number, item: any) => {
    if (isGeneralItem(item)) return itemSum;
    return itemSum + (item.quote_item_variants?.reduce((vSum: number, v: any) => {
      const qty = (v.xs || 0) + (v.s || 0) + (v.m || 0) + (v.l || 0) + (v.xl || 0) + (v.xxl || 0) + (v.xxxl || 0) + (v.xxxxl || 0) + (v.xxxxxl || 0);
      const savingsPerUnit = Math.max(0, (v.regular_price || 0) - (v.unit_price || 0));
      return vSum + (savingsPerUnit * qty);
    }, 0) || 0);
  }, 0) || 0;

  // --- VALIDITY COUNTDOWN ---
  const createdAt = new Date(quote.created_at);
  const expiryDate = new Date(createdAt);
  expiryDate.setDate(expiryDate.getDate() + QUOTE_VALIDITY_DAYS);
  const today = new Date();
  const msPerDay = 1000 * 60 * 60 * 24;
  const daysLeft = Math.ceil((expiryDate.getTime() - today.getTime()) / msPerDay);
  const isExpired = daysLeft <= 0;
  const isUrgent = !isExpired && daysLeft <= 3;

  // --- HANDLERS ---
  const handlePrint = () => {
    const originalTitle = document.title;
    const companyName = quote.customers?.company_name
      ? quote.customers.company_name.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()
      : "CLIENT";
    const referenceNum = quote.jobs?.[0]?.job_number || (quote.id ? quote.id.split('-')[0].toUpperCase() : "TBD");
    document.title = `${companyName}_QUOTE_${referenceNum}`;
    window.print();
    document.title = originalTitle;
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  const sendEmail = () => {
    const subject = encodeURIComponent(`Quote from YAYA SPORTS — Ref: ${quote.id.split('-')[0].toUpperCase()}`);
    const body = encodeURIComponent(`Hi ${quote.customers?.contact_name || 'there'},\n\nPlease find your quote for your custom apparel project here:\n\n${shareUrl}\n\nThis quote is valid for ${QUOTE_VALIDITY_DAYS} days.\n\nThank you for choosing YAYA SPORTS!`);
    window.location.href = `mailto:${quote.customers?.email}?subject=${subject}&body=${body}`;
  };

  const sendWhatsApp = () => {
    const cleanPhone = quote.customers?.phone?.replace(/\D/g, '');
    if (!cleanPhone) return alert("No phone number found for this customer.");
    const text = encodeURIComponent(`Hi ${quote.customers?.contact_name || 'there'}, here is your quote from YAYA SPORTS:\n\n${shareUrl}`);
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    alert(`${type} copied to clipboard!`);
  };

  const handleAccept = () => {
    if (!signatureName.trim()) return alert("Please type your name to sign.");
    const date = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    setAcceptanceStatus("accepted");
    setSignatureDate(date);
    setShowSignatureModal(false);
    try {
      localStorage.setItem(`quote-acceptance-${String(params.id)}`, JSON.stringify({
        status: "accepted", name: signatureName, date
      }));
    } catch {}
  };

  const handleDecline = () => {
    if (!confirm("Are you sure you want to decline this quote?")) return;
    setAcceptanceStatus("declined");
    try {
      localStorage.setItem(`quote-acceptance-${String(params.id)}`, JSON.stringify({
        status: "declined", name: signatureName, date: new Date().toLocaleDateString()
      }));
    } catch {}
  };

  const resetAcceptance = () => {
    if (!confirm("Reset acceptance status?")) return;
    setAcceptanceStatus("pending");
    setSignatureName("");
    setSignatureDate("");
    try { localStorage.removeItem(`quote-acceptance-${String(params.id)}`); } catch {}
  };

  // --- BUILD FLAT LIST OF ROWS (apparel variants + general items mixed) ---
  type Row = {
    type: "apparel" | "general";
    item: any;
    variant?: any;
    isFirstVariant: boolean;
    qty: number;
    rowTotal: number;
    parsedName: string;
    sides: string | null;
  };

  const rows: Row[] = [];
  quote.quote_items?.forEach((item: any) => {
    const parsed = parseDescription(item.description || "");
    if (isGeneralItem(item)) {
      const qty = item.quantity || 0;
      const rowTotal = qty * (item.unit_price || 0);
      rows.push({
        type: "general",
        item,
        isFirstVariant: true,
        qty,
        rowTotal,
        parsedName: parsed.name,
        sides: parsed.sides,
      });
    } else {
      item.quote_item_variants?.forEach((v: any, vIdx: number) => {
        const qty = (v.xs || 0) + (v.s || 0) + (v.m || 0) + (v.l || 0) + (v.xl || 0) + (v.xxl || 0) + (v.xxxl || 0) + (v.xxxxl || 0) + (v.xxxxxl || 0);
        if (qty === 0) return;
        rows.push({
          type: "apparel",
          item,
          variant: v,
          isFirstVariant: vIdx === 0,
          qty,
          rowTotal: qty * (v.unit_price || 0),
          parsedName: parsed.name,
          sides: parsed.sides,
        });
      });
    }
  });

  return (
    <div className="min-h-screen bg-[#0f1115] py-6 md:py-10 flex flex-col items-center font-sans text-slate-900 print:bg-white print:py-0 px-2 md:px-0 overflow-x-hidden">

      <style jsx global>{`
        @media print {
          nav, header, footer, .print-hidden { display: none !important; }
          @page { size: A4 portrait; margin: 0; }
          body { background-color: white !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; margin: 0 !important; padding: 0 !important; }
          .min-h-screen { padding: 0 !important; margin: 0 !important; background: white !important; }
          .invoice-canvas { transform: none !important; width: 210mm !important; min-height: 297mm !important; box-shadow: none !important; margin: 0 !important; }
          ::-webkit-scrollbar { display: none; }
        }
      `}</style>

      {/* COMMAND BAR */}
      <div className="w-full max-w-[210mm] mb-6 flex flex-col gap-3 print:hidden px-2 sm:px-0 mt-4">

        <div className="w-full flex justify-between items-center mb-2">
          <button onClick={() => router.back()} className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em] hover:text-white transition">
            ← Return to Dashboard
          </button>
          <button onClick={handlePrint} className="bg-white text-black px-6 py-2.5 rounded-full font-black uppercase text-[9px] tracking-widest shadow-2xl hover:scale-105 transition-all">
            Export PDF
          </button>
        </div>

        {/* QUOTE CONTROL PANEL */}
        <div className="w-full bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-2xl flex flex-col gap-3">

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">

            <label className="flex items-center gap-2 cursor-pointer bg-slate-800 hover:bg-slate-700 px-4 py-2.5 rounded-lg transition-all flex-1 sm:flex-none">
              <input type="checkbox" checked={includeHst} onChange={(e) => setIncludeHst(e.target.checked)} className="w-4 h-4 accent-sky-500" />
              <span className="text-white text-[10px] font-black uppercase tracking-widest">Include HST (13%)</span>
            </label>

            <div className="flex items-center gap-2 bg-slate-800 px-4 py-2.5 rounded-lg flex-1 sm:flex-none">
              <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Deposit %</span>
              <input
                type="number"
                min={0}
                max={100}
                value={depositPct}
                onChange={(e) => setDepositPct(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                className="w-12 bg-slate-900 text-white text-center text-[11px] font-black rounded px-1 py-0.5 outline-none border border-slate-700 focus:border-sky-500"
              />
            </div>

            <button onClick={() => setShowNotes(!showNotes)} className={`px-4 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex-1 sm:flex-none ${showNotes ? 'bg-sky-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'}`}>
              {showNotes ? 'Hide' : 'Show'} Notes / Terms
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch gap-3 border-t border-slate-800 pt-3">
            <div className="text-slate-400 text-[10px] font-black uppercase tracking-widest sm:w-[100px] shrink-0 flex items-center">
              Share Quote:
            </div>
            <button onClick={sendWhatsApp} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 rounded-lg font-black uppercase text-[9px] tracking-widest transition-all">
              WhatsApp
            </button>
            <button onClick={sendEmail} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 rounded-lg font-black uppercase text-[9px] tracking-widest transition-all">
              Email
            </button>
            <button onClick={() => copyToClipboard(shareUrl, 'Quote Link')} className="flex-1 bg-white/10 hover:bg-white/20 text-white py-2.5 rounded-lg font-black uppercase text-[9px] tracking-widest transition-all">
              Copy Link
            </button>
          </div>

          {showNotes && (
            <div className="border-t border-slate-800 pt-3">
              <div className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2">Notes / Custom Terms (saved on this device)</div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                placeholder="e.g. Artwork to be approved before production. Rush turnaround available for 15% surcharge..."
                className="w-full bg-slate-950 text-white text-[11px] font-medium rounded-lg p-3 outline-none border border-slate-800 focus:border-sky-500 resize-none"
              />
            </div>
          )}
        </div>
      </div>

      {/* DYNAMIC SCALING WRAPPER FOR MOBILE */}
      <div className="w-full flex justify-center pb-8 print:pb-0 overflow-hidden print:overflow-visible origin-top">

        <div className="print:!h-auto print:!block flex justify-center w-full origin-top" style={{ height: scale < 1 ? `${canvasHeight * scale}px` : 'auto' }}>

          <div
            ref={canvasRef}
            className="invoice-canvas bg-white p-[15mm] shadow-[0_40px_80px_rgba(0,0,0,0.4)] print:shadow-none relative flex flex-col border-t-[12px] border-black origin-top"
            style={{ width: '210mm', minHeight: '297mm', transform: scale < 1 ? `scale(${scale})` : 'none' }}
          >

            {/* HEADER BLOCK */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-[54px] font-black uppercase tracking-tighter leading-[0.8] text-black italic">YAYA<br/><span className="text-[#686a6c] opacity-30 not-italic">SPORTS</span></h1>
                <p className="text-[8px] font-black uppercase tracking-[0.5em] mt-4 text-[#686a6c]">Custom Production House</p>
              </div>
              <div className="text-right flex flex-col items-end">
                <h2 className="bg-black text-white px-5 py-1.5 text-xl font-black uppercase tracking-tighter mb-2 italic shadow-sm">Quote</h2>
                <div className="text-[9px] font-black uppercase tracking-[0.2em] px-3 py-1 border shadow-sm mt-1 border-sky-400 text-sky-500 bg-sky-50">
                  REF: {quote.id.split('-')[0].toUpperCase()}
                </div>

                {/* VALIDITY BADGE */}
                <div className={`mt-2 text-[8px] font-black uppercase tracking-[0.2em] px-3 py-1 border shadow-sm ${
                  isExpired ? 'border-red-400 text-red-600 bg-red-50'
                  : isUrgent ? 'border-amber-400 text-amber-700 bg-amber-50'
                  : 'border-emerald-400 text-emerald-600 bg-emerald-50'
                }`}>
                  {isExpired ? 'EXPIRED' : `VALID • ${daysLeft} DAY${daysLeft === 1 ? '' : 'S'} LEFT`}
                </div>

                {acceptanceStatus === "accepted" && (
                  <div className="mt-2 text-[8px] font-black uppercase tracking-[0.2em] px-3 py-1 border-2 border-emerald-500 text-emerald-700 bg-emerald-50 shadow-sm">
                    ✓ ACCEPTED BY {signatureName.toUpperCase()}
                  </div>
                )}
                {acceptanceStatus === "declined" && (
                  <div className="mt-2 text-[8px] font-black uppercase tracking-[0.2em] px-3 py-1 border-2 border-red-500 text-red-700 bg-red-50 shadow-sm">
                    ✗ DECLINED
                  </div>
                )}
              </div>
            </div>

            {/* INFO BLOCK */}
            <div className="flex justify-between items-end mb-6 border-b border-slate-200 pb-4">
              <div className="space-y-0.5">
                <div className="text-[8px] font-black text-[#686a6c] uppercase tracking-[0.4em] mb-1">Prepared For</div>
                <div className="text-xl font-black uppercase text-black tracking-tighter leading-none">{quote.customers?.company_name}</div>
                <div className="text-[10px] font-bold text-sky-600 lowercase tracking-tight pt-0.5">{quote.customers?.email}</div>
              </div>

              <div className="text-right space-y-1">
                <div className="text-[9px] font-black text-black">
                  <span className="uppercase tracking-[0.3em] mr-3 text-[#686a6c]">Date Issued</span>
                  {createdAt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase()}
                </div>
                <div className="text-[9px] font-black text-black">
                  <span className="uppercase tracking-[0.3em] mr-3 text-[#686a6c]">Valid Until</span>
                  {expiryDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase()}
                </div>
                <div className="text-[9px] font-black text-black">
                  <span className="uppercase tracking-[0.3em] mr-3 text-[#686a6c]">Status</span>
                  {quote.status}
                </div>
              </div>
            </div>

            {/* LINE ITEMS TABLE */}
            <div className="flex-grow">
              <table className="w-full text-left border-collapse table-fixed">
                <thead>
                  <tr className="border-b-2 border-black font-black text-black uppercase tracking-widest text-[8px] bg-slate-50/80">
                    <th className="py-2.5 w-[25%] pl-2">Description</th>
                    <th className="py-2.5 w-[5%] text-center">Qty</th>
                    <th className="py-2.5 w-[10%]">Color / Sides</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white bg-slate-100/50">XS</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white">S</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white">M</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white">L</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white">XL</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white bg-slate-100/50">2X</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white bg-slate-100/50">3X</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white bg-slate-100/50">4X</th>
                    <th className="py-2.5 w-[4%] text-center border-x border-white bg-slate-100/50">5X</th>
                    <th className="py-2.5 w-[10%] text-right pr-2">Disc. Price</th>
                    <th className="py-2.5 w-[14%] text-right pr-2">Total</th>
                  </tr>
                </thead>
                <tbody className="font-bold text-black uppercase text-[9px]">
                  {rows.map((row, idx) => {
                    if (row.type === "general") {
                      const itemColorHex = "#0891b2";
                      return (
                        <tr key={`g-${row.item.id}-${idx}`} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                          <td className="py-2 pl-2 font-black tracking-tight align-middle">
                            <div className="flex items-center">
                              <div className="shrink-0">{renderGarmentIcon(row.parsedName, itemColorHex)}</div>
                              <div className="whitespace-normal break-words leading-[1.1] pr-2 w-full">{row.parsedName}</div>
                            </div>
                          </td>
                          <td className="py-2 text-center font-black bg-slate-50/50 align-middle">{row.qty}</td>
                          <td className="py-2 font-black whitespace-normal break-words pr-1 align-middle leading-[1.1]" style={{ color: itemColorHex }}>
                            <div className="text-[9px]">PRINT MEDIA</div>
                            {row.sides && (
                              <div className="text-[7px] tracking-tight font-bold text-slate-500 mt-0.5">{row.sides.toUpperCase()}</div>
                            )}
                          </td>
                          <td colSpan={9} className="py-2 text-center text-[8px] text-slate-300 italic font-light align-middle">— no size breakdown —</td>
                          <td className="py-2 text-right pr-2 align-middle whitespace-nowrap">
                            <span className="text-sky-600 font-black">${(row.item.unit_price || 0).toFixed(2)}</span>
                          </td>
                          <td className="py-2 text-right font-black tracking-tighter pr-2 align-middle">${row.rowTotal.toFixed(2)}</td>
                        </tr>
                      );
                    }

                    const v = row.variant;
                    const itemColorHex = getColorHex(v.color);
                    return (
                      <tr key={`a-${v.id}`} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                        <td className="py-2 pl-2 font-black tracking-tight align-middle">
                          <div className="flex items-center">
                            <div className="shrink-0">
                              {row.isFirstVariant ? renderGarmentIcon(row.parsedName, itemColorHex) : <span className="w-5 mr-2 block"></span>}
                            </div>
                            <div className="whitespace-normal break-words leading-[1.1] pr-2 w-full">
                              {row.isFirstVariant ? row.parsedName : ""}
                            </div>
                          </div>
                        </td>
                        <td className="py-2 text-center font-black bg-slate-50/50 align-middle">{row.qty}</td>

                        <td className="py-2 font-black whitespace-normal break-words pr-1 align-middle leading-[1.1]" style={{ color: itemColorHex }}>
                          <div>{v.color || 'STANDARD'}</div>
                          {row.isFirstVariant && row.sides && (
                            <div className="text-[7px] tracking-tight font-bold text-slate-500 mt-0.5">{row.sides.toUpperCase()}</div>
                          )}
                        </td>

                        <td className={`py-2 text-center align-middle ${v.xs === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xs || '-'}</td>
                        <td className={`py-2 text-center align-middle ${v.s === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.s || '-'}</td>
                        <td className={`py-2 text-center align-middle ${v.m === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.m || '-'}</td>
                        <td className={`py-2 text-center align-middle ${v.l === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.l || '-'}</td>
                        <td className={`py-2 text-center align-middle ${v.xl === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xl || '-'}</td>
                        <td className={`py-2 text-center bg-slate-50/50 align-middle ${v.xxl === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xxl || '-'}</td>
                        <td className={`py-2 text-center bg-slate-50/50 align-middle ${v.xxxl === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xxxl || '-'}</td>
                        <td className={`py-2 text-center bg-slate-50/50 align-middle ${v.xxxxl === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xxxxl || '-'}</td>
                        <td className={`py-2 text-center bg-slate-50/50 align-middle ${v.xxxxxl === 0 ? 'text-slate-200 font-light' : 'text-black'}`}>{v.xxxxxl || '-'}</td>

                        <td className="py-2 text-right pr-2 align-middle whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {v.regular_price > v.unit_price && (
                              <span className="text-[8px] text-red-500 line-through tracking-tighter">${v.regular_price?.toFixed(2)}</span>
                            )}
                            <span className="text-sky-600 font-black">${v.unit_price?.toFixed(2)}</span>
                          </div>
                        </td>
                        <td className="py-2 text-right font-black tracking-tighter pr-2 align-middle">${row.rowTotal.toFixed(2)}</td>
                      </tr>
                    );
                  })}

                  {rows.length === 0 && (
                    <tr><td colSpan={14} className="py-8 text-center text-slate-400 text-[10px] tracking-widest font-bold">No items on this quote.</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* CUSTOM NOTES (only printed if entered) */}
            {notes.trim() && (
              <div className="mt-6 pt-4 border-t border-slate-200">
                <div className="text-[8px] font-black text-[#686a6c] uppercase tracking-[0.4em] mb-2">Notes & Terms</div>
                <p className="text-[9px] text-slate-700 leading-relaxed whitespace-pre-wrap">{notes}</p>
              </div>
            )}

            {/* BOTTOM SECTION */}
            <div className="flex justify-between items-start pt-6 border-t-[6px] border-black mt-auto">

              <div className="w-1/2 space-y-5 pr-4">
                <div className="text-[9px] font-black text-black uppercase tracking-[0.1em] space-y-1">
                  <div className="text-sm tracking-tighter italic mb-1.5">YAYA SPORTS INCORPORATED</div>
                  <div className="text-slate-500">39 BRANCHWOOD ST</div>
                  <div className="text-slate-500">OTTAWA - ON. - K2B6X8</div>
                  <div className="text-slate-500">613-666-YAYA (9292)</div>
                  <div className="text-slate-500">GST/HST#: 71925 3957 RT0001</div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-200">
                  <span className="text-sky-600 text-[10px] tracking-widest font-black uppercase">E-TRANSFER TO: INFO@YAYASPORTS.CA</span>
                </div>

                <p className="text-[8px] normal-case font-bold text-slate-400 leading-relaxed max-w-[320px] pt-2">
                  * This quote is valid for {QUOTE_VALIDITY_DAYS} days from the date issued. Production begins immediately upon artwork approval and deposit. Thank you for choosing YAYA SPORTS.
                </p>
              </div>

              {/* FINANCIALS PANEL */}
              <div className="w-[280px] bg-slate-50 p-5 border border-slate-200 rounded-lg shadow-sm">
                <div className="space-y-3 text-[10px] font-black text-black uppercase tracking-widest">
                  <div className="flex justify-between items-center text-slate-500">
                    <span>Sub-Total</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  {totalSavings > 0 && (
                    <div className="flex justify-between items-center text-emerald-600 bg-emerald-50 px-2 py-1 rounded">
                      <span>You Save</span>
                      <span>-${totalSavings.toFixed(2)}</span>
                    </div>
                  )}
                  {includeHst ? (
                    <div className="flex justify-between items-center text-slate-500 border-b border-slate-200 pb-3">
                      <span>HST (13%)</span>
                      <span>${tax.toFixed(2)}</span>
                    </div>
                  ) : (
                    <div className="flex justify-between items-center text-slate-400 border-b border-slate-200 pb-3 text-[8px]">
                      <span>Tax</span>
                      <span className="italic normal-case tracking-normal">Not Included</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-1 text-2xl tracking-tighter text-black leading-none">
                    <span>Quote Total</span>
                    <span>${grandTotal.toFixed(2)}</span>
                  </div>

                  {depositPct > 0 && depositPct < 100 && (
                    <div className="pt-3 border-t border-slate-200 space-y-1">
                      <div className="flex justify-between items-center text-[9px] text-sky-600">
                        <span>{depositPct}% Deposit Due</span>
                        <span>${deposit.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center text-[8px] text-slate-400">
                        <span>Balance on Delivery</span>
                        <span>${(grandTotal - deposit).toFixed(2)}</span>
                      </div>
                    </div>
                  )}

                  {acceptanceStatus === "accepted" ? (
                    <div className="pt-6 border-t border-emerald-300 mt-2">
                      <div className="text-[7px] text-slate-400 tracking-[0.4em] mb-1">SIGNED & ACCEPTED</div>
                      <div className="text-[10px] font-black text-emerald-700 tracking-tight italic" style={{ fontFamily: 'cursive' }}>
                        {signatureName}
                      </div>
                      <div className="text-[7px] text-slate-500 mt-1 tracking-widest">{signatureDate}</div>
                    </div>
                  ) : (
                    <div className="pt-10 border-b border-slate-300 text-[7px] text-[#686a6c] pb-1 text-center tracking-[0.5em]">
                      CUSTOMER APPROVAL
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ACCEPT / DECLINE FLOATING BAR */}
      {acceptanceStatus === "pending" && !isExpired && (
        <div className="print:hidden fixed bottom-0 left-0 right-0 bg-gradient-to-r from-slate-900 to-black border-t-2 border-sky-500/30 p-4 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-40">
          <div className="max-w-[210mm] mx-auto flex flex-col sm:flex-row items-center gap-3">
            <div className="text-white text-[11px] font-black uppercase tracking-widest text-center sm:text-left flex-1">
              Ready to proceed? <span className="text-sky-400">Approve this quote to lock in pricing.</span>
            </div>
            <button onClick={handleDecline} className="w-full sm:w-auto bg-slate-800 hover:bg-red-600 text-white px-5 py-2.5 rounded-lg font-black uppercase text-[10px] tracking-widest transition-all">
              Decline
            </button>
            <button onClick={() => setShowSignatureModal(true)} className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2.5 rounded-lg font-black uppercase text-[10px] tracking-widest transition-all shadow-lg">
              ✓ Accept & Sign
            </button>
          </div>
        </div>
      )}

      {acceptanceStatus !== "pending" && (
        <div className="print:hidden fixed bottom-4 right-4 z-40">
          <button onClick={resetAcceptance} className="bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white px-3 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest border border-slate-700 transition-all">
            Reset Status
          </button>
        </div>
      )}

      {/* SIGNATURE MODAL */}
      {showSignatureModal && (
        <div className="print:hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setShowSignatureModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md p-6 md:p-8 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="border-b border-slate-200 pb-4 mb-5">
              <h2 className="text-xl font-black uppercase italic tracking-tighter text-black">Accept Quote</h2>
              <p className="text-[10px] font-bold uppercase tracking-widest mt-2 text-slate-500">Type your name below to sign and approve</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest block mb-2 text-slate-500">Full Name <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={signatureName}
                  onChange={(e) => setSignatureName(e.target.value)}
                  placeholder={quote.customers?.contact_name || "Your name"}
                  className="w-full rounded-xl px-4 py-3 text-base font-bold outline-none transition-colors shadow-inner border border-slate-300 focus:border-emerald-500 bg-slate-50"
                  autoFocus
                />
              </div>

              {signatureName.trim() && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                  <div className="text-[8px] tracking-[0.3em] font-black text-emerald-700 uppercase mb-1">Preview</div>
                  <div className="text-2xl text-emerald-700 italic" style={{ fontFamily: 'cursive' }}>{signatureName}</div>
                  <div className="text-[9px] text-slate-500 mt-1">Dated: {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                </div>
              )}

              <p className="text-[9px] text-slate-500 leading-relaxed">
                By typing your name, you agree this is a legally binding electronic signature accepting the terms of this quote, including pricing and turnaround.
              </p>

              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowSignatureModal(false)} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all">
                  Cancel
                </button>
                <button onClick={handleAccept} disabled={!signatureName.trim()} className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                  Sign & Accept
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
