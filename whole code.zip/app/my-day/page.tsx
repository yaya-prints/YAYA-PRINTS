"use client";

/* =====================================================================================
   /MY-DAY  —  PERSONAL DAY PLANNER
   =====================================================================================

   ⚠️  RUN THIS SQL IN YOUR SUPABASE SQL EDITOR BEFORE USING THIS PAGE
   --------------------------------------------------------------------------------------

   -- 1. Main personal-task table (separate from production /todos table)
   create table if not exists my_day_tasks (
     id uuid primary key default gen_random_uuid(),
     created_at timestamptz default now() not null,
     updated_at timestamptz default now() not null,

     -- core fields
     title text not null,
     notes text,                                  -- longer description
     target_date date not null,                   -- which day it lives on
     target_time time,                            -- null = unscheduled (in the pool)
     duration_minutes integer default 30,

     -- status
     is_completed boolean default false not null,
     completed_at timestamptz,
     is_deleted boolean default false not null,

     -- categorization
     category text default 'personal',            -- personal | work | admin | sales | production | health | other
     priority text default 'normal',              -- low | normal | high | urgent
     energy text,                                 -- low | medium | high  (energy required to do this)

     -- linking to existing CRM data (both nullable)
     job_id uuid references jobs(id) on delete set null,
     customer_id uuid references customers(id) on delete set null,

     -- subtasks: stored as jsonb array of { id, title, done }
     subtasks jsonb default '[]'::jsonb,

     -- recurrence
     recurrence text default 'none',              -- none | daily | weekdays | weekly | monthly
     recurrence_parent uuid                       -- if this is a generated instance, points to template
       references my_day_tasks(id) on delete cascade,

     -- ordering inside a day for unscheduled pool
     sort_order integer default 0
   );

   create index if not exists idx_my_day_tasks_date on my_day_tasks(target_date) where is_deleted = false;
   create index if not exists idx_my_day_tasks_recurrence on my_day_tasks(recurrence) where recurrence <> 'none';

   -- 2. Daily review table (one row per day, captures end-of-day reflection)
   create table if not exists my_day_reviews (
     id uuid primary key default gen_random_uuid(),
     review_date date not null unique,
     wins text,
     blockers text,
     mood integer,           -- 1-5
     energy integer,         -- 1-5
     tomorrow_focus text,
     created_at timestamptz default now() not null,
     updated_at timestamptz default now() not null
   );

   -- 3. Auto-update updated_at on row changes
   create or replace function set_updated_at() returns trigger as $$
   begin new.updated_at := now(); return new; end;
   $$ language plpgsql;

   drop trigger if exists trg_my_day_tasks_updated on my_day_tasks;
   create trigger trg_my_day_tasks_updated before update on my_day_tasks
     for each row execute function set_updated_at();

   drop trigger if exists trg_my_day_reviews_updated on my_day_reviews;
   create trigger trg_my_day_reviews_updated before update on my_day_reviews
     for each row execute function set_updated_at();

   ===================================================================================== */

import { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────────
const CATEGORIES = [
  { id: "personal",   label: "Personal",   color: "violet"  },
  { id: "work",       label: "Work",       color: "blue"    },
  { id: "admin",      label: "Admin",      color: "slate"   },
  { id: "sales",      label: "Sales",      color: "emerald" },
  { id: "production", label: "Production", color: "orange"  },
  { id: "health",     label: "Health",     color: "rose"    },
  { id: "other",      label: "Other",      color: "amber"   },
];

const CATEGORY_CLASSES: Record<string, { bg: string; text: string; ring: string; chip: string }> = {
  violet:  { bg: "bg-violet-500/10",  text: "text-violet-400",  ring: "ring-violet-500/40",  chip: "bg-violet-500" },
  blue:    { bg: "bg-blue-500/10",    text: "text-blue-400",    ring: "ring-blue-500/40",    chip: "bg-blue-500" },
  slate:   { bg: "bg-slate-500/10",   text: "text-slate-400",   ring: "ring-slate-500/40",   chip: "bg-slate-500" },
  emerald: { bg: "bg-emerald-500/10", text: "text-emerald-400", ring: "ring-emerald-500/40", chip: "bg-emerald-500" },
  orange:  { bg: "bg-orange-500/10",  text: "text-orange-400",  ring: "ring-orange-500/40",  chip: "bg-orange-500" },
  rose:    { bg: "bg-rose-500/10",    text: "text-rose-400",    ring: "ring-rose-500/40",    chip: "bg-rose-500" },
  amber:   { bg: "bg-amber-500/10",   text: "text-amber-400",   ring: "ring-amber-500/40",   chip: "bg-amber-500" },
};

const PRIORITIES = [
  { id: "low",    label: "Low",    color: "text-slate-400" },
  { id: "normal", label: "Normal", color: "text-sky-400" },
  { id: "high",   label: "High",   color: "text-amber-400" },
  { id: "urgent", label: "Urgent", color: "text-red-400" },
];

const ENERGY_LEVELS = [
  { id: "low",    icon: "🌑", label: "Low" },
  { id: "medium", icon: "🌗", label: "Med" },
  { id: "high",   icon: "🌕", label: "High" },
];

const RECURRENCE_OPTIONS = [
  { id: "none",     label: "Once" },
  { id: "daily",    label: "Daily" },
  { id: "weekdays", label: "Weekdays" },
  { id: "weekly",   label: "Weekly" },
  { id: "monthly",  label: "Monthly" },
];

// ─── JOB PIPELINE ────────────────────────────────────────────────────────────────
// Maps internal job stage → an action verb you'd put on a calendar
const STAGE_VERB: Record<string, string> = {
  "Incoming":  "Review",
  "Artwork":   "Artwork",
  "Sourcing":  "Source",
  "Ordered":   "Track",
  "Received":  "Receive",
  "Staged":    "Stage",
  "Printing":  "Print",
  "Pressing":  "Press",
  "Finishing": "Finish",
  "Dispatch":  "Dispatch",
  "Billing":   "Bill",
  "Paid":      "Close",
};

// "Next-action" stages — the things you actually physically do day-to-day
const NEXT_ACTION_STAGES = ["Artwork", "Printing", "Pressing", "Finishing", "Dispatch"];

const STAGE_COLORS: Record<string, { bg: string; text: string; ring: string; chip: string; cat: string }> = {
  Incoming:  { bg: "bg-slate-500/10",   text: "text-slate-400",   ring: "ring-slate-500/40",   chip: "bg-slate-500",   cat: "production" },
  Artwork:   { bg: "bg-fuchsia-500/10", text: "text-fuchsia-400", ring: "ring-fuchsia-500/40", chip: "bg-fuchsia-500", cat: "production" },
  Sourcing:  { bg: "bg-amber-500/10",   text: "text-amber-400",   ring: "ring-amber-500/40",   chip: "bg-amber-500",   cat: "production" },
  Ordered:   { bg: "bg-amber-500/10",   text: "text-amber-400",   ring: "ring-amber-500/40",   chip: "bg-amber-500",   cat: "production" },
  Received:  { bg: "bg-amber-500/10",   text: "text-amber-400",   ring: "ring-amber-500/40",   chip: "bg-amber-500",   cat: "production" },
  Staged:    { bg: "bg-amber-500/10",   text: "text-amber-400",   ring: "ring-amber-500/40",   chip: "bg-amber-500",   cat: "production" },
  Printing:  { bg: "bg-pink-500/10",    text: "text-pink-400",    ring: "ring-pink-500/40",    chip: "bg-pink-500",    cat: "production" },
  Pressing:  { bg: "bg-red-500/10",     text: "text-red-400",     ring: "ring-red-500/40",     chip: "bg-red-500",     cat: "production" },
  Finishing: { bg: "bg-teal-500/10",    text: "text-teal-400",    ring: "ring-teal-500/40",    chip: "bg-teal-500",    cat: "production" },
  Dispatch:  { bg: "bg-indigo-500/10",  text: "text-indigo-400",  ring: "ring-indigo-500/40",  chip: "bg-indigo-500",  cat: "production" },
  Billing:   { bg: "bg-blue-500/10",    text: "text-blue-400",    ring: "ring-blue-500/40",    chip: "bg-blue-500",    cat: "admin" },
  Paid:      { bg: "bg-emerald-500/10", text: "text-emerald-400", ring: "ring-emerald-500/40", chip: "bg-emerald-500", cat: "admin" },
};

// Build a short item summary from quote_items: "24x Hoodies + 12x Tees"
function summarizeItems(quoteItems: any[] | undefined | null, maxLen = 40): string {
  if (!quoteItems || quoteItems.length === 0) return "";
  const parts = quoteItems
    .map((qi: any) => {
      const qty = qi.quantity || 0;
      // Strip "(Single Sided)" / "(Double Sided)" parens from description
      const name = (qi.description || "").replace(/\s*\([^)]+\)\s*$/, "").trim();
      return qty > 0 && name ? `${qty}x ${name}` : "";
    })
    .filter(Boolean);
  if (parts.length === 0) return "";
  let summary = parts.join(" + ");
  if (summary.length > maxLen) summary = summary.slice(0, maxLen - 1) + "…";
  return summary;
}

// Build the auto-title: "Press Prestige Moving — 24x Hoodies"
function buildJobTaskTitle(job: any): string {
  const verb = STAGE_VERB[job.stage] || job.stage || "Do";
  const customer = job.quotes?.customers?.company_name || job.title || `#${job.job_number}`;
  const items = summarizeItems(job.quotes?.quote_items);
  return items ? `${verb} ${customer} — ${items}` : `${verb} ${customer}`;
}

// Hours displayed on the day timeline
const TIMELINE_START_HOUR = 6;   // 6am
const TIMELINE_END_HOUR   = 23;  // 11pm
const PIXELS_PER_HOUR     = 56;

// localStorage cache keys (offline fallback)
const LS_TASK_CACHE = "myday-task-cache-v1";
const LS_QUEUE      = "myday-write-queue-v1";

// ─── TYPES ────────────────────────────────────────────────────────────────────────
type Subtask = { id: string; title: string; done: boolean };

type Task = {
  id: string;
  title: string;
  notes: string | null;
  target_date: string;
  target_time: string | null;
  duration_minutes: number;
  is_completed: boolean;
  completed_at: string | null;
  is_deleted: boolean;
  category: string;
  priority: string;
  energy: string | null;
  job_id: string | null;
  customer_id: string | null;
  subtasks: Subtask[];
  recurrence: string;
  recurrence_parent: string | null;
  sort_order: number;
  // joined data
  jobs?: { job_number: string; title: string } | null;
  customers?: { company_name: string } | null;
};

type Review = {
  review_date: string;
  wins: string;
  blockers: string;
  mood: number | null;
  energy: number | null;
  tomorrow_focus: string;
};

type WriteOp =
  | { kind: "insert"; table: string; payload: any; tempId: string }
  | { kind: "update"; table: string; id: string; payload: any }
  | { kind: "upsert"; table: string; payload: any; onConflict: string }
  | { kind: "delete"; table: string; id: string };

// ─── HELPERS ──────────────────────────────────────────────────────────────────────
const todayISO   = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD in local TZ
const yesterdayISO = () => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toLocaleDateString("en-CA"); };
const fmtDayHeader = (iso: string) => {
  const d = new Date(iso + "T12:00:00");
  return d.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
};
const minsFromTime = (t: string | null): number => {
  if (!t) return 0;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
const timeFromMins = (mins: number): string => {
  const h = Math.floor(mins / 60).toString().padStart(2, "0");
  const m = (mins % 60).toString().padStart(2, "0");
  return `${h}:${m}:00`;
};
const fmt12hr = (t: string | null): string => {
  if (!t) return "";
  const [hStr, mStr] = t.split(":");
  let h = parseInt(hStr); const m = mStr;
  const am = h < 12; const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${m} ${am ? "AM" : "PM"}`;
};

// Quick-capture parser: extracts time, date, duration, priority hints from a single string
function parseQuickCapture(input: string): {
  title: string;
  target_time: string | null;
  target_date: string;
  duration_minutes: number;
  priority: string;
  category: string;
} {
  let s = input.trim();
  const today = todayISO();
  let target_date = today;
  let target_time: string | null = null;
  let duration_minutes = 30;
  let priority = "normal";
  let category = "personal";

  // Date keywords
  if (/\btoday\b/i.test(s)) { s = s.replace(/\btoday\b/gi, "").trim(); }
  if (/\btomorrow\b/i.test(s)) {
    const d = new Date(); d.setDate(d.getDate() + 1);
    target_date = d.toLocaleDateString("en-CA");
    s = s.replace(/\btomorrow\b/gi, "").trim();
  }
  // "next monday" etc.
  const dowMap: Record<string, number> = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
  const dowMatch = s.match(/\bnext\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i);
  if (dowMatch) {
    const targetDow = dowMap[dowMatch[1].toLowerCase()];
    const d = new Date();
    let delta = (targetDow + 7 - d.getDay()) % 7;
    if (delta === 0) delta = 7;
    d.setDate(d.getDate() + delta);
    target_date = d.toLocaleDateString("en-CA");
    s = s.replace(dowMatch[0], "").trim();
  }

  // Time: "at 3pm", "at 9:30am", "@ 14:00"
  const timeMatch = s.match(/\b(?:at|@)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i);
  if (timeMatch) {
    let h = parseInt(timeMatch[1]); const m = timeMatch[2] ? parseInt(timeMatch[2]) : 0;
    const ampm = timeMatch[3]?.toLowerCase();
    if (ampm === "pm" && h < 12) h += 12;
    if (ampm === "am" && h === 12) h = 0;
    target_time = `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:00`;
    s = s.replace(timeMatch[0], "").trim();
  }

  // Duration: "for 45m", "for 2h", "for 1.5h"
  const durMatch = s.match(/\bfor\s+(\d+(?:\.\d+)?)\s*(h|hr|hour|hours|m|min|mins|minutes)\b/i);
  if (durMatch) {
    const n = parseFloat(durMatch[1]);
    const unit = durMatch[2].toLowerCase();
    duration_minutes = unit.startsWith("h") ? Math.round(n * 60) : Math.round(n);
    s = s.replace(durMatch[0], "").trim();
  }

  // Priority hashtags
  if (/!{2,}|#urgent\b/i.test(s)) { priority = "urgent"; s = s.replace(/!{2,}|#urgent/gi, "").trim(); }
  else if (/!|#high\b/i.test(s)) { priority = "high"; s = s.replace(/!|#high/gi, "").trim(); }
  else if (/#low\b/i.test(s)) { priority = "low"; s = s.replace(/#low/gi, "").trim(); }

  // Category hashtag
  for (const c of CATEGORIES) {
    const re = new RegExp(`#${c.id}\\b`, "i");
    if (re.test(s)) { category = c.id; s = s.replace(re, "").trim(); break; }
  }

  return { title: s.replace(/\s+/g, " ").trim() || "Untitled task", target_time, target_date, duration_minutes, priority, category };
}

// ─── WRITE QUEUE (offline support) ────────────────────────────────────────────────
function loadQueue(): WriteOp[] {
  try { return JSON.parse(localStorage.getItem(LS_QUEUE) || "[]"); } catch { return []; }
}
function saveQueue(q: WriteOp[]) {
  try { localStorage.setItem(LS_QUEUE, JSON.stringify(q)); } catch {}
}
async function flushQueue(onProgress?: () => void): Promise<{ ok: number; failed: number }> {
  const q = loadQueue();
  if (q.length === 0) return { ok: 0, failed: 0 };
  let ok = 0, failed = 0;
  const remaining: WriteOp[] = [];
  for (const op of q) {
    try {
      if (op.kind === "insert") {
        const { error } = await supabase.from(op.table).insert([op.payload]);
        if (error) throw error;
      } else if (op.kind === "update") {
        const { error } = await supabase.from(op.table).update(op.payload).eq("id", op.id);
        if (error) throw error;
      } else if (op.kind === "upsert") {
        const { error } = await supabase.from(op.table).upsert(op.payload, { onConflict: op.onConflict });
        if (error) throw error;
      } else if (op.kind === "delete") {
        const { error } = await supabase.from(op.table).delete().eq("id", op.id);
        if (error) throw error;
      }
      ok++;
    } catch {
      failed++;
      remaining.push(op);
    }
    onProgress?.();
  }
  saveQueue(remaining);
  return { ok, failed };
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────────
export default function MyDayPage() {
  const router = useRouter();
  const [selectedDate, setSelectedDate] = useState<string>(todayISO());
  const [tasks, setTasks] = useState<Task[]>([]);
  const [review, setReview] = useState<Review>({ review_date: todayISO(), wins: "", blockers: "", mood: null, energy: null, tomorrow_focus: "" });
  const [jobs, setJobs] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [isOnline, setIsOnline] = useState(true);
  const [queueDepth, setQueueDepth] = useState(0);
  const [loading, setLoading] = useState(true);

  // UI state
  const [captureInput, setCaptureInput] = useState("");
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showReview, setShowReview] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);

  // Job picker state
  const [showJobPicker, setShowJobPicker] = useState(false);
  const [pickerFilter, setPickerFilter] = useState<"next" | "all" | "due">("next");
  const [pickerSearch, setPickerSearch] = useState("");
  const [scheduleJobModal, setScheduleJobModal] = useState<any | null>(null); // job being detail-scheduled

  // Drag state — null means nothing dragging; otherwise this is the job being dragged
  const [draggingJob, setDraggingJob] = useState<any | null>(null);
  const [dropHint, setDropHint] = useState<{ kind: "time" | "pool"; time?: string } | null>(null);

  // ─── ONLINE/OFFLINE DETECTION ─────────────────────────────────────────────────
  useEffect(() => {
    const updateOnline = () => setIsOnline(navigator.onLine);
    updateOnline();
    window.addEventListener("online",  updateOnline);
    window.addEventListener("offline", updateOnline);
    return () => {
      window.removeEventListener("online",  updateOnline);
      window.removeEventListener("offline", updateOnline);
    };
  }, []);

  useEffect(() => {
    setQueueDepth(loadQueue().length);
  }, []);

  // Auto-flush queue when we come back online
  useEffect(() => {
    if (!isOnline) return;
    (async () => {
      const result = await flushQueue();
      if (result.ok > 0) await fetchTasks(selectedDate);
      setQueueDepth(loadQueue().length);
    })();
  }, [isOnline]); // eslint-disable-line react-hooks/exhaustive-deps

  // ─── VOICE DETECTION ──────────────────────────────────────────────────────────
  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    setVoiceSupported(!!SR);
  }, []);

  // ─── DATA FETCH ───────────────────────────────────────────────────────────────
  const fetchTasks = useCallback(async (date: string) => {
    setLoading(true);
    try {
      // Try server first
      const { data, error } = await supabase
        .from("my_day_tasks")
        .select(`
          *,
          jobs ( job_number, title ),
          customers ( company_name )
        `)
        .eq("target_date", date)
        .eq("is_deleted", false)
        .order("target_time", { ascending: true, nullsFirst: false })
        .order("sort_order", { ascending: true });

      if (error) throw error;
      const fetched = (data || []) as Task[];
      setTasks(fetched);
      // Cache for offline
      try {
        const cache = JSON.parse(localStorage.getItem(LS_TASK_CACHE) || "{}");
        cache[date] = fetched;
        localStorage.setItem(LS_TASK_CACHE, JSON.stringify(cache));
      } catch {}
    } catch {
      // Offline / error → fall back to cache
      try {
        const cache = JSON.parse(localStorage.getItem(LS_TASK_CACHE) || "{}");
        if (cache[date]) setTasks(cache[date]);
      } catch {}
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchReview = useCallback(async (date: string) => {
    try {
      const { data } = await supabase.from("my_day_reviews").select("*").eq("review_date", date).maybeSingle();
      if (data) {
        setReview(data);
      } else {
        setReview({ review_date: date, wins: "", blockers: "", mood: null, energy: null, tomorrow_focus: "" });
      }
    } catch {
      setReview({ review_date: date, wins: "", blockers: "", mood: null, energy: null, tomorrow_focus: "" });
    }
  }, []);

  const fetchLinks = useCallback(async () => {
    try {
      const [jRes, cRes] = await Promise.all([
        supabase.from("jobs")
          .select("id, job_number, title, stage, due_date, created_at, updated_at, quotes(customers(company_name, contact_name), quote_items(description, quantity))")
          .not("stage", "in", '("Paid","Completed")')
          .order("updated_at", { ascending: false })
          .limit(150),
        supabase.from("customers").select("id, company_name").order("company_name").limit(200),
      ]);
      if (jRes.data) setJobs(jRes.data);
      if (cRes.data) setCustomers(cRes.data);
    } catch {}
  }, []);

  useEffect(() => { fetchTasks(selectedDate); fetchReview(selectedDate); }, [selectedDate, fetchTasks, fetchReview]);
  useEffect(() => { fetchLinks(); }, [fetchLinks]);

  // Realtime sync
  useEffect(() => {
    const ch = supabase.channel("my-day-sync").on("postgres_changes",
      { event: "*", schema: "public", table: "my_day_tasks" },
      () => fetchTasks(selectedDate)
    ).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [selectedDate, fetchTasks]);

  // ─── RECURRING TASK SPAWNER ───────────────────────────────────────────────────
  // On mount + when date is "today", expand recurring templates that haven't yet spawned for today.
  useEffect(() => {
    if (selectedDate !== todayISO()) return;
    (async () => {
      try {
        const today = todayISO();
        const { data: templates } = await supabase
          .from("my_day_tasks")
          .select("*")
          .neq("recurrence", "none")
          .is("recurrence_parent", null)
          .eq("is_deleted", false);
        if (!templates) return;

        const dow = new Date(today + "T12:00:00").getDay(); // 0..6
        const dom = new Date(today + "T12:00:00").getDate();
        const weekday = dow >= 1 && dow <= 5;

        const { data: existing } = await supabase
          .from("my_day_tasks")
          .select("recurrence_parent")
          .eq("target_date", today)
          .not("recurrence_parent", "is", null);

        const alreadySpawned = new Set((existing || []).map((r: any) => r.recurrence_parent));

        const toCreate = templates.filter((t: any) => {
          if (alreadySpawned.has(t.id)) return false;
          if (t.recurrence === "daily") return true;
          if (t.recurrence === "weekdays") return weekday;
          if (t.recurrence === "weekly") return new Date(t.target_date + "T12:00:00").getDay() === dow;
          if (t.recurrence === "monthly") return new Date(t.target_date + "T12:00:00").getDate() === dom;
          return false;
        });

        if (toCreate.length === 0) return;
        const rows = toCreate.map((t: any) => ({
          title: t.title, notes: t.notes, target_date: today, target_time: t.target_time,
          duration_minutes: t.duration_minutes, category: t.category, priority: t.priority,
          energy: t.energy, job_id: t.job_id, customer_id: t.customer_id,
          subtasks: t.subtasks, recurrence: "none", recurrence_parent: t.id,
        }));
        await supabase.from("my_day_tasks").insert(rows);
        fetchTasks(today);
      } catch (e) { console.error("Recurrence spawn failed", e); }
    })();
  }, [selectedDate, fetchTasks]);

  // ─── WRITE HELPERS (queue if offline) ─────────────────────────────────────────
  const enqueueOrRun = async (op: WriteOp): Promise<boolean> => {
    if (!navigator.onLine) {
      const q = loadQueue(); q.push(op); saveQueue(q); setQueueDepth(q.length);
      return false;
    }
    try {
      if (op.kind === "insert") {
        const { error } = await supabase.from(op.table).insert([op.payload]);
        if (error) throw error;
      } else if (op.kind === "update") {
        const { error } = await supabase.from(op.table).update(op.payload).eq("id", op.id);
        if (error) throw error;
      } else if (op.kind === "upsert") {
        const { error } = await supabase.from(op.table).upsert(op.payload, { onConflict: op.onConflict });
        if (error) throw error;
      } else if (op.kind === "delete") {
        const { error } = await supabase.from(op.table).delete().eq("id", op.id);
        if (error) throw error;
      }
      return true;
    } catch {
      const q = loadQueue(); q.push(op); saveQueue(q); setQueueDepth(q.length);
      return false;
    }
  };

  // ─── ACTIONS ──────────────────────────────────────────────────────────────────
  const addFromQuickCapture = async () => {
    if (!captureInput.trim()) return;
    const parsed = parseQuickCapture(captureInput);
    const tempId = "tmp-" + Math.random().toString(36).slice(2);
    const optimistic: Task = {
      id: tempId, title: parsed.title, notes: null,
      target_date: parsed.target_date, target_time: parsed.target_time,
      duration_minutes: parsed.duration_minutes, is_completed: false, completed_at: null, is_deleted: false,
      category: parsed.category, priority: parsed.priority, energy: null,
      job_id: null, customer_id: null, subtasks: [], recurrence: "none", recurrence_parent: null, sort_order: 0,
    };
    setTasks(prev => [...prev, optimistic]);
    setCaptureInput("");

    const synced = await enqueueOrRun({ kind: "insert", table: "my_day_tasks", payload: { ...optimistic, id: undefined }, tempId });
    if (synced) {
      // refetch to pick up real id
      if (parsed.target_date === selectedDate) fetchTasks(selectedDate);
    }
  };

  const toggleComplete = async (task: Task) => {
    const next = !task.is_completed;
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, is_completed: next, completed_at: next ? new Date().toISOString() : null } : t));
    await enqueueOrRun({
      kind: "update", table: "my_day_tasks", id: task.id,
      payload: { is_completed: next, completed_at: next ? new Date().toISOString() : null },
    });
  };

  const deleteTask = async (task: Task) => {
    setTasks(prev => prev.filter(t => t.id !== task.id));
    await enqueueOrRun({ kind: "update", table: "my_day_tasks", id: task.id, payload: { is_deleted: true } });
  };

  const updateTask = async (task: Task, patch: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, ...patch } : t));
    // strip joined data + id from payload
    const cleanPatch: any = { ...patch };
    delete cleanPatch.jobs; delete cleanPatch.customers; delete cleanPatch.id;
    await enqueueOrRun({ kind: "update", table: "my_day_tasks", id: task.id, payload: cleanPatch });
  };

  const carryOverFromYesterday = async () => {
    try {
      const y = yesterdayISO();
      const { data: incomplete } = await supabase
        .from("my_day_tasks")
        .select("*")
        .eq("target_date", y).eq("is_completed", false).eq("is_deleted", false)
        .is("recurrence_parent", null);
      if (!incomplete || incomplete.length === 0) {
        alert("Nothing to carry over from yesterday.");
        return;
      }
      if (!confirm(`Carry over ${incomplete.length} incomplete task${incomplete.length > 1 ? "s" : ""} from yesterday to today?`)) return;
      await supabase.from("my_day_tasks").update({ target_date: todayISO() }).in("id", incomplete.map((t: any) => t.id));
      fetchTasks(selectedDate);
    } catch (e) { console.error(e); alert("Carry-over failed."); }
  };

  // ─── SCHEDULE JOB FROM PICKER ─────────────────────────────────────────────────
  // Creates BOTH a my_day_tasks row (linked to job) AND a production todos row
  // so the shop floor sees the same task. Either can be null = unscheduled.
  const scheduleJobFromPicker = async (
    job: any,
    opts: { date?: string; time?: string | null; duration?: number; titleOverride?: string; notes?: string; energy?: string | null; priority?: string }
  ) => {
    const date = opts.date || selectedDate;
    const time = opts.time === undefined ? null : opts.time; // explicit null = unscheduled
    const duration = opts.duration ?? 60;
    const title = opts.titleOverride || buildJobTaskTitle(job);
    const customer_id = job.quotes?.customers?.id || null;
    const stageInfo = STAGE_COLORS[job.stage] || STAGE_COLORS.Incoming;

    // 1) Optimistic insert into my_day_tasks
    const tempId = "tmp-" + Math.random().toString(36).slice(2);
    const optimistic: Task = {
      id: tempId, title, notes: opts.notes ?? null,
      target_date: date, target_time: time,
      duration_minutes: duration, is_completed: false, completed_at: null, is_deleted: false,
      category: stageInfo.cat, priority: opts.priority ?? "normal", energy: opts.energy ?? null,
      job_id: job.id, customer_id,
      subtasks: [], recurrence: "none", recurrence_parent: null, sort_order: 0,
      jobs: { job_number: job.job_number, title: job.title } as any,
      customers: customer_id ? { company_name: job.quotes?.customers?.company_name || "" } as any : null,
    };
    if (date === selectedDate) setTasks(prev => [...prev, optimistic]);

    // 2) Send both inserts in parallel (queued if offline)
    const myDayPayload = {
      title, notes: opts.notes ?? null,
      target_date: date, target_time: time,
      duration_minutes: duration, category: stageInfo.cat,
      priority: opts.priority ?? "normal", energy: opts.energy ?? null,
      job_id: job.id, customer_id,
    };
    const todosPayload = {
      task: title,
      job_id: job.id,
      target_date: date,
      target_time: time,
      duration_minutes: duration,
      is_completed: false,
      is_deleted: false,
    };

    const [r1, r2] = await Promise.all([
      enqueueOrRun({ kind: "insert", table: "my_day_tasks", payload: myDayPayload, tempId }),
      enqueueOrRun({ kind: "insert", table: "todos",        payload: todosPayload,  tempId: tempId + "-prod" }),
    ]);

    // Refetch to swap in real ID + joined data
    if (r1 && date === selectedDate) await fetchTasks(selectedDate);

    if (!r1 && !r2) {
      // both queued — let user know
      console.warn("Both writes queued for offline retry");
    }
    return r1 && r2;
  };

  // ─── DERIVED VIEWS ────────────────────────────────────────────────────────────
  const scheduledTasks = useMemo(() => tasks.filter(t => t.target_time), [tasks]);
  const unscheduledTasks = useMemo(() => tasks.filter(t => !t.target_time && !t.is_completed), [tasks]);
  const completedToday = useMemo(() => tasks.filter(t => t.is_completed).length, [tasks]);
  const totalToday = tasks.length;
  const progressPct = totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;
  const isToday = selectedDate === todayISO();

  // ─── VOICE CAPTURE ────────────────────────────────────────────────────────────
  const recognitionRef = useRef<any>(null);
  const startVoiceCapture = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { alert("Voice input is not supported in this browser. Try Chrome or Edge."); return; }
    if (voiceListening) { recognitionRef.current?.stop(); return; }
    const rec = new SR();
    rec.lang = "en-US"; rec.continuous = false; rec.interimResults = true;
    rec.onstart = () => setVoiceListening(true);
    rec.onend = () => setVoiceListening(false);
    rec.onerror = () => setVoiceListening(false);
    rec.onresult = (e: any) => {
      let txt = "";
      for (let i = e.resultIndex; i < e.results.length; i++) txt += e.results[i][0].transcript;
      setCaptureInput(txt);
    };
    recognitionRef.current = rec; rec.start();
  };

  // ─── RENDER ───────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0f1115] text-slate-900 dark:text-slate-200">

      {/* ─── HEADER ─────────────────────────────────────────────────────── */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-[1600px] mx-auto px-4 md:px-6 py-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-400 dark:text-slate-500 mb-1">
              {fmtDayHeader(selectedDate)}
            </div>
            <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tighter italic text-black dark:text-white leading-none">
              {isToday ? "My Day" : selectedDate === yesterdayISO() ? "Yesterday" : "Day View"}
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* connection / queue */}
            <div className={`text-[9px] font-black uppercase tracking-widest px-3 py-2 rounded-full border ${
              isOnline
                ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30"
                : "bg-amber-500/10 text-amber-500 border-amber-500/30"
            }`}>
              {isOnline ? "● Online" : "○ Offline"}
              {queueDepth > 0 && <span className="ml-2 opacity-70">{queueDepth} queued</span>}
            </div>

            {/* date controls */}
            <button onClick={() => { const d = new Date(selectedDate + "T12:00:00"); d.setDate(d.getDate() - 1); setSelectedDate(d.toLocaleDateString("en-CA")); }}
              className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">←</button>
            <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}
              className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-[11px] font-black border-none outline-none" />
            <button onClick={() => { const d = new Date(selectedDate + "T12:00:00"); d.setDate(d.getDate() + 1); setSelectedDate(d.toLocaleDateString("en-CA")); }}
              className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">→</button>
            <button onClick={() => setSelectedDate(todayISO())}
              className="px-3 py-2 rounded-lg bg-sky-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-sky-500">Today</button>

            {isToday && (
              <button onClick={carryOverFromYesterday}
                className="px-3 py-2 rounded-lg bg-violet-500/10 text-violet-500 border border-violet-500/30 text-[10px] font-black uppercase tracking-widest hover:bg-violet-500/20">
                ↻ Carry Over
              </button>
            )}

            <button onClick={() => setShowJobPicker(true)}
              className="px-3 py-2 rounded-lg bg-orange-500/10 text-orange-500 border border-orange-500/30 text-[10px] font-black uppercase tracking-widest hover:bg-orange-500/20">
              + From Jobs
            </button>

            <button onClick={() => setShowReview(true)}
              className="px-3 py-2 rounded-lg bg-amber-500/10 text-amber-500 border border-amber-500/30 text-[10px] font-black uppercase tracking-widest hover:bg-amber-500/20">
              Daily Review
            </button>
          </div>
        </div>

        {/* Progress strip */}
        <div className="max-w-[1600px] mx-auto px-4 md:px-6 pb-4">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
            <span>{completedToday} / {totalToday} done</span>
            <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-sky-500 transition-all duration-500" style={{ width: `${progressPct}%` }} />
            </div>
            <span className="text-emerald-500">{progressPct}%</span>
          </div>
        </div>
      </div>

      {/* ─── MAIN GRID ──────────────────────────────────────────────────────── */}
      <div className="max-w-[1600px] mx-auto px-4 md:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* ─── LEFT RAIL: QUICK CAPTURE + UNSCHEDULED + STATS ─────────────── */}
        <div className="lg:col-span-4 space-y-5">

          {/* Quick capture */}
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500 mb-2">Quick Capture</div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={captureInput}
                onChange={e => setCaptureInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") addFromQuickCapture(); }}
                placeholder="Email John tomorrow at 2pm for 30m #work !"
                className="flex-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-medium outline-none focus:border-sky-500"
              />
              {voiceSupported && (
                <button onClick={startVoiceCapture}
                  className={`px-3 py-3 rounded-xl text-lg ${voiceListening ? "bg-red-500 text-white animate-pulse" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`}
                  title={voiceListening ? "Stop listening" : "Voice input"}>
                  🎙
                </button>
              )}
              <button onClick={addFromQuickCapture}
                className="px-4 py-3 rounded-xl bg-sky-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-sky-500 transition-all">
                Add
              </button>
            </div>
            <div className="text-[9px] text-slate-400 dark:text-slate-500 mt-2 leading-relaxed">
              Hints: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">at 3pm</code>, <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">tomorrow</code>, <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">for 45m</code>, <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">#work</code>, <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">!</code> high · <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">!!</code> urgent
            </div>
          </div>

          {/* Unscheduled pool */}
          <div
            className={`bg-white dark:bg-slate-950 border-2 border-dashed rounded-2xl p-4 shadow-sm transition-all ${
              draggingJob && dropHint?.kind === "pool"
                ? "border-orange-500 bg-orange-500/5"
                : draggingJob
                  ? "border-orange-300 dark:border-orange-700"
                  : "border-slate-200 dark:border-slate-800 border-solid"
            }`}
            onDragOver={(e) => { if (draggingJob) { e.preventDefault(); setDropHint({ kind: "pool" }); } }}
            onDragLeave={() => { if (dropHint?.kind === "pool") setDropHint(null); }}
            onDrop={async (e) => {
              if (!draggingJob) return;
              e.preventDefault();
              const job = draggingJob; setDraggingJob(null); setDropHint(null);
              await scheduleJobFromPicker(job, { date: selectedDate, time: null });
            }}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500">
                {draggingJob ? "Drop here for unscheduled" : "Unscheduled · Pool"}
              </div>
              <div className="text-[9px] font-black text-slate-400">{unscheduledTasks.length}</div>
            </div>
            <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-1">
              {unscheduledTasks.length === 0 ? (
                <div className="text-center py-6 text-[10px] tracking-widest font-bold text-slate-300 dark:text-slate-700 uppercase">
                  {draggingJob ? "Release to add as unscheduled" : "No unscheduled tasks"}
                </div>
              ) : unscheduledTasks.map(t => (
                <TaskCard key={t.id} task={t} compact onToggle={toggleComplete} onEdit={setEditingTask} onDelete={deleteTask} />
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500 mb-3">Day Stats</div>
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Tasks" value={String(totalToday)} />
              <Stat label="Done" value={String(completedToday)} accent="emerald" />
              <Stat label="Hours" value={(tasks.reduce((s, t) => s + (t.duration_minutes || 0), 0) / 60).toFixed(1)} accent="sky" />
            </div>
          </div>
        </div>

        {/* ─── CENTER: TIMELINE ───────────────────────────────────────────── */}
        <div className="lg:col-span-8">
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500">Schedule</div>
              <div className="text-[9px] font-black text-slate-400">{scheduledTasks.length} scheduled</div>
            </div>
            <Timeline
              tasks={scheduledTasks}
              onToggle={toggleComplete}
              onEdit={setEditingTask}
              isToday={isToday}
              draggingJob={draggingJob}
              dropHint={dropHint}
              setDropHint={setDropHint}
              onDropJobAtTime={async (time) => {
                if (!draggingJob) return;
                const job = draggingJob; setDraggingJob(null); setDropHint(null);
                await scheduleJobFromPicker(job, { date: selectedDate, time });
              }}
            />
          </div>
        </div>
      </div>

      {/* ─── JOB PICKER PANEL ──────────────────────────────────────────── */}
      {showJobPicker && (
        <JobPicker
          jobs={jobs}
          filter={pickerFilter}
          setFilter={setPickerFilter}
          search={pickerSearch}
          setSearch={setPickerSearch}
          onClose={() => setShowJobPicker(false)}
          onClickJob={(job) => { setScheduleJobModal(job); }}
          onDragStart={(job) => setDraggingJob(job)}
          onDragEnd={() => { setDraggingJob(null); setDropHint(null); }}
        />
      )}

      {/* ─── SCHEDULE JOB MODAL (detailed scheduling) ──────────────────── */}
      {scheduleJobModal && (
        <ScheduleJobModal
          job={scheduleJobModal}
          defaultDate={selectedDate}
          onClose={() => setScheduleJobModal(null)}
          onSchedule={async (opts) => {
            await scheduleJobFromPicker(scheduleJobModal, opts);
            setScheduleJobModal(null);
          }}
        />
      )}

      {/* ─── EDIT MODAL ─────────────────────────────────────────────────── */}
      {editingTask && (
        <EditTaskModal
          task={editingTask}
          jobs={jobs}
          customers={customers}
          onClose={() => setEditingTask(null)}
          onSave={(patch) => { updateTask(editingTask, patch); setEditingTask(null); }}
          onDelete={() => { deleteTask(editingTask); setEditingTask(null); }}
        />
      )}

      {/* ─── DAILY REVIEW MODAL ─────────────────────────────────────────── */}
      {showReview && (
        <DailyReviewModal
          review={review}
          tasks={tasks}
          onClose={() => setShowReview(false)}
          onSave={async (r) => {
            setReview(r);
            await enqueueOrRun({ kind: "upsert", table: "my_day_reviews", payload: r, onConflict: "review_date" });
            setShowReview(false);
          }}
        />
      )}
    </div>
  );
}

// ─── COMPONENTS ────────────────────────────────────────────────────────────────

function Stat({ label, value, accent = "slate" }: { label: string; value: string; accent?: string }) {
  const colors: Record<string, string> = {
    slate: "text-slate-700 dark:text-slate-200",
    emerald: "text-emerald-500",
    sky: "text-sky-500",
  };
  return (
    <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-3 text-center">
      <div className={`text-2xl font-black tracking-tighter ${colors[accent]}`}>{value}</div>
      <div className="text-[8px] font-black uppercase tracking-widest text-slate-400 mt-1">{label}</div>
    </div>
  );
}

function TaskCard({ task, compact, onToggle, onEdit, onDelete }: {
  task: Task; compact?: boolean;
  onToggle: (t: Task) => void; onEdit: (t: Task) => void; onDelete: (t: Task) => void;
}) {
  const cat = CATEGORIES.find(c => c.id === task.category) || CATEGORIES[0];
  const cls = CATEGORY_CLASSES[cat.color];
  const prio = PRIORITIES.find(p => p.id === task.priority);
  const subtaskProgress = task.subtasks?.length > 0
    ? `${task.subtasks.filter(s => s.done).length}/${task.subtasks.length}`
    : null;

  return (
    <div className={`group relative rounded-xl border ${cls.bg} border-slate-200/50 dark:border-slate-800 hover:ring-1 ${cls.ring} transition-all`}>
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${cls.chip} rounded-l-xl`}></div>
      <div className="flex items-start gap-2 p-3 pl-4">
        <button onClick={() => onToggle(task)}
          className={`mt-0.5 w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
            task.is_completed
              ? "bg-emerald-500 border-emerald-500 text-white"
              : "border-slate-300 dark:border-slate-600 hover:border-emerald-400"
          }`}>
          {task.is_completed && <span className="text-[10px] leading-none">✓</span>}
        </button>

        <div className="flex-1 min-w-0">
          <div className={`text-xs font-bold leading-tight cursor-pointer ${task.is_completed ? "line-through opacity-50" : ""}`}
            onClick={() => onEdit(task)}>
            {task.title}
          </div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1.5 text-[8px] font-black uppercase tracking-widest">
            <span className={cls.text}>{cat.label}</span>
            {task.target_time && <span className="text-slate-400">{fmt12hr(task.target_time)}</span>}
            {!compact && task.duration_minutes > 0 && <span className="text-slate-400">{task.duration_minutes}m</span>}
            {task.priority !== "normal" && prio && <span className={prio.color}>● {prio.label}</span>}
            {task.energy && <span className="text-slate-400">{ENERGY_LEVELS.find(e => e.id === task.energy)?.icon}</span>}
            {subtaskProgress && <span className="text-slate-400">☑ {subtaskProgress}</span>}
            {task.recurrence_parent && <span className="text-violet-400">↻ recurring</span>}
            {task.jobs && <span className="text-orange-400 normal-case tracking-tight">#{task.jobs.job_number}</span>}
            {task.customers && <span className="text-teal-400 normal-case tracking-tight">{task.customers.company_name}</span>}
          </div>
        </div>

        <button onClick={() => onDelete(task)}
          className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 text-xs px-1 transition-all" title="Delete">
          ×
        </button>
      </div>
    </div>
  );
}

function Timeline({ tasks, onToggle, onEdit, isToday, draggingJob, dropHint, setDropHint, onDropJobAtTime }: {
  tasks: Task[]; onToggle: (t: Task) => void; onEdit: (t: Task) => void; isToday: boolean;
  draggingJob?: any | null;
  dropHint?: { kind: "time" | "pool"; time?: string } | null;
  setDropHint?: (h: { kind: "time" | "pool"; time?: string } | null) => void;
  onDropJobAtTime?: (time: string) => void;
}) {
  const hours = [];
  for (let h = TIMELINE_START_HOUR; h <= TIMELINE_END_HOUR; h++) hours.push(h);

  const gridRef = useRef<HTMLDivElement>(null);

  // Convert pointer Y → snapped time string ("HH:MM:SS"), 15-min increments
  const yToSnappedTime = (clientY: number): string | null => {
    const grid = gridRef.current;
    if (!grid) return null;
    const rect = grid.getBoundingClientRect();
    const y = Math.max(0, Math.min(clientY - rect.top, rect.height));
    const totalMinutes = (y / PIXELS_PER_HOUR) * 60;
    const startMins = TIMELINE_START_HOUR * 60;
    const absMins = startMins + totalMinutes;
    const snapped = Math.round(absMins / 15) * 15;
    const clampedMin = Math.min(Math.max(snapped, startMins), (TIMELINE_END_HOUR + 1) * 60 - 15);
    return timeFromMins(clampedMin);
  };

  // Current-time marker
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 60_000); return () => clearInterval(t); }, []);
  const nowMins = now.getHours() * 60 + now.getMinutes();
  const startMins = TIMELINE_START_HOUR * 60;
  const endMins = (TIMELINE_END_HOUR + 1) * 60;
  const showNowLine = isToday && nowMins >= startMins && nowMins <= endMins;
  const nowTop = ((nowMins - startMins) / 60) * PIXELS_PER_HOUR;

  // Detect overlapping tasks to render side-by-side
  type Positioned = Task & { _top: number; _height: number; _column: number; _columns: number };
  const positioned: Positioned[] = useMemo(() => {
    const sorted = [...tasks].sort((a, b) => minsFromTime(a.target_time) - minsFromTime(b.target_time));
    const result: Positioned[] = [];
    const lanes: { end: number }[] = [];
    for (const t of sorted) {
      const start = minsFromTime(t.target_time);
      const end = start + (t.duration_minutes || 30);
      let lane = lanes.findIndex(l => l.end <= start);
      if (lane === -1) { lanes.push({ end }); lane = lanes.length - 1; }
      else lanes[lane].end = end;
      result.push({
        ...t,
        _top: ((start - startMins) / 60) * PIXELS_PER_HOUR,
        _height: Math.max(28, (((end - start) / 60) * PIXELS_PER_HOUR) - 2),
        _column: lane,
        _columns: 0, // filled below
      });
    }
    // determine columns count for each cluster (simplified: use total lane count)
    const totalLanes = lanes.length || 1;
    return result.map(p => ({ ...p, _columns: totalLanes }));
  }, [tasks, startMins]);

  return (
    <div
      ref={gridRef}
      className={`relative transition-colors ${draggingJob ? "ring-2 ring-orange-500/40 ring-inset rounded-lg" : ""}`}
      style={{ height: (TIMELINE_END_HOUR - TIMELINE_START_HOUR + 1) * PIXELS_PER_HOUR }}
      onDragOver={(e) => {
        if (!draggingJob) return;
        e.preventDefault();
        const t = yToSnappedTime(e.clientY);
        if (t) setDropHint?.({ kind: "time", time: t });
      }}
      onDragLeave={(e) => {
        if (!draggingJob) return;
        // Only clear if leaving the grid entirely
        const rect = gridRef.current?.getBoundingClientRect();
        if (rect && (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom)) {
          setDropHint?.(null);
        }
      }}
      onDrop={(e) => {
        if (!draggingJob) return;
        e.preventDefault();
        const t = yToSnappedTime(e.clientY);
        if (t) onDropJobAtTime?.(t);
      }}
    >
      {/* Drop preview line */}
      {draggingJob && dropHint?.kind === "time" && dropHint.time && (
        <div className="absolute left-12 md:left-14 right-0 z-30 pointer-events-none transition-all"
             style={{ top: ((minsFromTime(dropHint.time) - TIMELINE_START_HOUR * 60) / 60) * PIXELS_PER_HOUR }}>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-orange-500 -ml-1.5 ring-2 ring-white dark:ring-slate-950 shadow-[0_0_12px_rgba(249,115,22,0.7)]"></div>
            <div className="flex-1 h-0.5 bg-orange-500"></div>
            <div className="text-[9px] font-black tracking-widest text-white bg-orange-500 px-2 py-0.5 rounded ml-2 shadow-md">
              DROP @ {fmt12hr(dropHint.time)}
            </div>
          </div>
        </div>
      )}

      {/* Hour grid */}
      {hours.map((h, idx) => (
        <div key={h} className="absolute left-0 right-0 border-t border-slate-100 dark:border-slate-800 flex items-start"
          style={{ top: idx * PIXELS_PER_HOUR, height: PIXELS_PER_HOUR }}>
          <div className="w-12 md:w-14 shrink-0 -mt-2 pl-1 text-[9px] font-black uppercase tracking-widest text-slate-300 dark:text-slate-600">
            {h === 0 ? "12 AM" : h < 12 ? `${h} AM` : h === 12 ? "12 PM" : `${h - 12} PM`}
          </div>
        </div>
      ))}

      {/* Now line */}
      {showNowLine && (
        <div className="absolute left-12 md:left-14 right-0 z-20 pointer-events-none" style={{ top: nowTop }}>
          <div className="flex items-center">
            <div className="w-2 h-2 rounded-full bg-red-500 -ml-1 shadow-[0_0_8px_rgba(239,68,68,0.6)]"></div>
            <div className="flex-1 h-px bg-red-500/60"></div>
            <div className="text-[8px] font-black tracking-widest text-red-500 ml-1">{fmt12hr(timeFromMins(nowMins))}</div>
          </div>
        </div>
      )}

      {/* Tasks */}
      <div className={`absolute left-12 md:left-14 right-0 top-0 bottom-0 ${draggingJob ? "pointer-events-none" : ""}`}>
        {positioned.length === 0 ? (
          <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold tracking-widest uppercase text-slate-300 dark:text-slate-700 pointer-events-none">
            {draggingJob ? "Drop anywhere on the timeline" : "No scheduled tasks for this day"}
          </div>
        ) : positioned.map(t => {
          const cat = CATEGORIES.find(c => c.id === t.category) || CATEGORIES[0];
          const cls = CATEGORY_CLASSES[cat.color];
          const widthPct = 100 / Math.max(1, t._columns);
          const leftPct = t._column * widthPct;
          return (
            <div key={t.id}
              onClick={() => onEdit(t)}
              className={`absolute rounded-lg ${cls.bg} ring-1 ${cls.ring} cursor-pointer hover:scale-[1.01] transition-all overflow-hidden`}
              style={{ top: t._top, height: t._height, left: `calc(${leftPct}% + 4px)`, width: `calc(${widthPct}% - 8px)` }}>
              <div className={`absolute left-0 top-0 bottom-0 w-1 ${cls.chip}`}></div>
              <div className="p-2 pl-3 h-full flex flex-col">
                <div className="flex items-start gap-2">
                  <button onClick={(e) => { e.stopPropagation(); onToggle(t); }}
                    className={`w-3.5 h-3.5 rounded border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                      t.is_completed ? "bg-emerald-500 border-emerald-500 text-white" : "border-slate-400 hover:border-emerald-400"
                    }`}>
                    {t.is_completed && <span className="text-[8px] leading-none">✓</span>}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className={`text-[11px] font-black tracking-tight leading-tight ${t.is_completed ? "line-through opacity-50" : ""}`}>{t.title}</div>
                    <div className="text-[8px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mt-0.5">
                      {fmt12hr(t.target_time)} · {t.duration_minutes}m
                    </div>
                  </div>
                </div>
                {t._height > 60 && (
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[8px] font-black uppercase tracking-widest">
                    <span className={cls.text}>{cat.label}</span>
                    {t.energy && <span>{ENERGY_LEVELS.find(e => e.id === t.energy)?.icon}</span>}
                    {t.jobs && <span className="text-orange-400 normal-case tracking-tight">#{t.jobs.job_number}</span>}
                    {t.customers && <span className="text-teal-400 normal-case tracking-tight truncate">{t.customers.company_name}</span>}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function EditTaskModal({ task, jobs, customers, onClose, onSave, onDelete }: {
  task: Task; jobs: any[]; customers: any[];
  onClose: () => void; onSave: (patch: Partial<Task>) => void; onDelete: () => void;
}) {
  const [draft, setDraft] = useState<Task>(task);
  const [newSubtask, setNewSubtask] = useState("");

  const updateSubtask = (id: string, patch: Partial<Subtask>) => {
    setDraft({ ...draft, subtasks: draft.subtasks.map(s => s.id === id ? { ...s, ...patch } : s) });
  };
  const addSubtask = () => {
    if (!newSubtask.trim()) return;
    setDraft({ ...draft, subtasks: [...(draft.subtasks || []), { id: Math.random().toString(36).slice(2), title: newSubtask, done: false }] });
    setNewSubtask("");
  };
  const removeSubtask = (id: string) => {
    setDraft({ ...draft, subtasks: draft.subtasks.filter(s => s.id !== id) });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={onClose}>
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-5">
          <h2 className="text-xl font-black uppercase italic tracking-tighter text-black dark:text-white">Edit Task</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-black dark:hover:text-white text-xs font-black uppercase tracking-widest">Close ✕</button>
        </div>

        <div className="space-y-4">
          <Field label="Title">
            <input value={draft.title} onChange={e => setDraft({ ...draft, title: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-sky-500" autoFocus />
          </Field>

          <Field label="Notes">
            <textarea value={draft.notes || ""} onChange={e => setDraft({ ...draft, notes: e.target.value })} rows={3}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-medium outline-none focus:border-sky-500 resize-none" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Date">
              <input type="date" value={draft.target_date} onChange={e => setDraft({ ...draft, target_date: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-sky-500" />
            </Field>
            <Field label="Time">
              <input type="time" value={(draft.target_time || "").slice(0, 5)}
                onChange={e => setDraft({ ...draft, target_time: e.target.value ? `${e.target.value}:00` : null })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-sky-500" />
            </Field>
            <Field label="Duration (min)">
              <input type="number" min={5} step={5} value={draft.duration_minutes} onChange={e => setDraft({ ...draft, duration_minutes: parseInt(e.target.value) || 30 })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-sky-500" />
            </Field>
            <Field label="Recurrence">
              <select value={draft.recurrence} onChange={e => setDraft({ ...draft, recurrence: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-sky-500">
                {RECURRENCE_OPTIONS.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}
              </select>
            </Field>
          </div>

          <Field label="Category">
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map(c => {
                const cls = CATEGORY_CLASSES[c.color];
                const active = draft.category === c.id;
                return (
                  <button key={c.id} onClick={() => setDraft({ ...draft, category: c.id })}
                    className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${
                      active ? `${cls.bg} ${cls.text} ${cls.ring} ring-1 border-transparent` : "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500"
                    }`}>{c.label}</button>
                );
              })}
            </div>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Priority">
              <div className="flex gap-1">
                {PRIORITIES.map(p => (
                  <button key={p.id} onClick={() => setDraft({ ...draft, priority: p.id })}
                    className={`flex-1 px-2 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${
                      draft.priority === p.id ? `${p.color} border-current` : "text-slate-400 border-slate-200 dark:border-slate-800"
                    }`}>{p.label}</button>
                ))}
              </div>
            </Field>
            <Field label="Energy Required">
              <div className="flex gap-1">
                {ENERGY_LEVELS.map(e => (
                  <button key={e.id} onClick={() => setDraft({ ...draft, energy: draft.energy === e.id ? null : e.id })}
                    className={`flex-1 px-2 py-2 rounded-lg text-sm font-black border transition-all ${
                      draft.energy === e.id ? "bg-amber-500/10 text-amber-500 border-amber-500/40" : "border-slate-200 dark:border-slate-800"
                    }`} title={e.label}>{e.icon}</button>
                ))}
              </div>
            </Field>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Link to Job (optional)">
              <select value={draft.job_id || ""} onChange={e => setDraft({ ...draft, job_id: e.target.value || null })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs font-bold outline-none focus:border-sky-500">
                <option value="">— None —</option>
                {jobs.map(j => <option key={j.id} value={j.id}>#{j.job_number} — {j.title}</option>)}
              </select>
            </Field>
            <Field label="Link to Customer (optional)">
              <select value={draft.customer_id || ""} onChange={e => setDraft({ ...draft, customer_id: e.target.value || null })}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs font-bold outline-none focus:border-sky-500">
                <option value="">— None —</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.company_name}</option>)}
              </select>
            </Field>
          </div>

          {/* Subtasks */}
          <Field label="Subtasks / Checklist">
            <div className="space-y-1.5">
              {(draft.subtasks || []).map(s => (
                <div key={s.id} className="flex items-center gap-2 bg-slate-50 dark:bg-slate-900 rounded-lg px-3 py-2">
                  <button onClick={() => updateSubtask(s.id, { done: !s.done })}
                    className={`w-3.5 h-3.5 rounded border-2 flex items-center justify-center shrink-0 ${
                      s.done ? "bg-emerald-500 border-emerald-500 text-white" : "border-slate-400"
                    }`}>{s.done && <span className="text-[8px]">✓</span>}</button>
                  <input value={s.title} onChange={e => updateSubtask(s.id, { title: e.target.value })}
                    className={`flex-1 bg-transparent outline-none text-xs font-medium ${s.done ? "line-through opacity-50" : ""}`} />
                  <button onClick={() => removeSubtask(s.id)} className="text-slate-400 hover:text-red-500 text-xs">×</button>
                </div>
              ))}
              <div className="flex gap-2">
                <input value={newSubtask} onChange={e => setNewSubtask(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addSubtask(); } }}
                  placeholder="Add subtask…"
                  className="flex-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-medium outline-none focus:border-sky-500" />
                <button onClick={addSubtask} className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">Add</button>
              </div>
            </div>
          </Field>
        </div>

        <div className="flex gap-2 mt-6 pt-5 border-t border-slate-200 dark:border-slate-800">
          <button onClick={onDelete} className="px-4 py-2.5 rounded-xl bg-red-500/10 text-red-500 border border-red-500/30 text-[10px] font-black uppercase tracking-widest hover:bg-red-500/20">Delete</button>
          <div className="flex-1"></div>
          <button onClick={onClose} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">Cancel</button>
          <button onClick={() => onSave(draft)} className="px-5 py-2.5 rounded-xl bg-sky-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-sky-500">Save</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500 mb-1.5">{label}</div>
      {children}
    </div>
  );
}

function DailyReviewModal({ review, tasks, onClose, onSave }: {
  review: Review; tasks: Task[];
  onClose: () => void; onSave: (r: Review) => void;
}) {
  const [draft, setDraft] = useState<Review>(review);
  const completed = tasks.filter(t => t.is_completed);
  const carriedOver = tasks.filter(t => !t.is_completed);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={onClose}>
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-5">
          <div>
            <h2 className="text-xl font-black uppercase italic tracking-tighter text-black dark:text-white">Daily Review</h2>
            <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">{fmtDayHeader(draft.review_date)}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-black dark:hover:text-white text-xs font-black uppercase tracking-widest">Close ✕</button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 text-center">
            <div className="text-2xl font-black tracking-tighter text-emerald-500">{completed.length}</div>
            <div className="text-[8px] font-black uppercase tracking-widest text-emerald-500/70 mt-1">Done</div>
          </div>
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-center">
            <div className="text-2xl font-black tracking-tighter text-amber-500">{carriedOver.length}</div>
            <div className="text-[8px] font-black uppercase tracking-widest text-amber-500/70 mt-1">Carried Over</div>
          </div>
          <div className="bg-sky-500/10 border border-sky-500/30 rounded-xl p-3 text-center">
            <div className="text-2xl font-black tracking-tighter text-sky-500">{(tasks.reduce((s, t) => s + (t.duration_minutes || 0), 0) / 60).toFixed(1)}h</div>
            <div className="text-[8px] font-black uppercase tracking-widest text-sky-500/70 mt-1">Planned</div>
          </div>
        </div>

        <div className="space-y-4">
          <Field label="Wins · What went well today?">
            <textarea value={draft.wins} onChange={e => setDraft({ ...draft, wins: e.target.value })} rows={3}
              placeholder="Closed two quotes. Finished the artwork backlog…"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-medium outline-none focus:border-emerald-500 resize-none" />
          </Field>

          <Field label="Blockers · What slowed you down?">
            <textarea value={draft.blockers} onChange={e => setDraft({ ...draft, blockers: e.target.value })} rows={3}
              placeholder="Vendor didn't respond. Internet was slow…"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-medium outline-none focus:border-amber-500 resize-none" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Mood (1–5)">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(n => (
                  <button key={n} onClick={() => setDraft({ ...draft, mood: n })}
                    className={`flex-1 py-2 rounded-lg text-lg border transition-all ${
                      draft.mood === n ? "bg-violet-500/10 border-violet-500/40" : "border-slate-200 dark:border-slate-800"
                    }`}>{["😞", "😐", "🙂", "😀", "🤩"][n - 1]}</button>
                ))}
              </div>
            </Field>
            <Field label="Energy (1–5)">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(n => (
                  <button key={n} onClick={() => setDraft({ ...draft, energy: n })}
                    className={`flex-1 py-2 rounded-lg text-[10px] font-black border transition-all ${
                      draft.energy === n ? "bg-sky-500/10 text-sky-500 border-sky-500/40" : "text-slate-400 border-slate-200 dark:border-slate-800"
                    }`}>{n}</button>
                ))}
              </div>
            </Field>
          </div>

          <Field label="Tomorrow's #1 Focus">
            <input value={draft.tomorrow_focus} onChange={e => setDraft({ ...draft, tomorrow_focus: e.target.value })}
              placeholder="Ship the Anderson order"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-sky-500" />
          </Field>

          {carriedOver.length > 0 && (
            <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3">
              <div className="text-[9px] font-black uppercase tracking-widest text-amber-600 dark:text-amber-500 mb-2">{carriedOver.length} unfinished task{carriedOver.length > 1 ? "s" : ""} on this day</div>
              <ul className="text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
                {carriedOver.slice(0, 5).map(t => <li key={t.id}>· {t.title}</li>)}
                {carriedOver.length > 5 && <li className="text-slate-400">…and {carriedOver.length - 5} more</li>}
              </ul>
            </div>
          )}
        </div>

        <div className="flex gap-2 mt-6 pt-5 border-t border-slate-200 dark:border-slate-800">
          <button onClick={onClose} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">Cancel</button>
          <div className="flex-1"></div>
          <button onClick={() => onSave(draft)} className="px-5 py-2.5 rounded-xl bg-sky-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-sky-500">Save Review</button>
        </div>
      </div>
    </div>
  );
}

// ─── JOB PICKER PANEL ────────────────────────────────────────────────────────────
function JobPicker({ jobs, filter, setFilter, search, setSearch, onClose, onClickJob, onDragStart, onDragEnd }: {
  jobs: any[];
  filter: "next" | "all" | "due";
  setFilter: (f: "next" | "all" | "due") => void;
  search: string;
  setSearch: (s: string) => void;
  onClose: () => void;
  onClickJob: (job: any) => void;
  onDragStart: (job: any) => void;
  onDragEnd: () => void;
}) {
  // Filter by tab
  const filtered = useMemo(() => {
    let list = jobs;
    if (filter === "next") {
      list = jobs.filter(j => NEXT_ACTION_STAGES.includes(j.stage));
    } else if (filter === "due") {
      const sevenDaysOut = new Date();
      sevenDaysOut.setDate(sevenDaysOut.getDate() + 7);
      list = jobs.filter(j => {
        if (!j.due_date) return false;
        const due = new Date(j.due_date + "T12:00:00");
        return due <= sevenDaysOut;
      });
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(j =>
        (j.job_number || "").toString().toLowerCase().includes(q) ||
        (j.title || "").toLowerCase().includes(q) ||
        (j.quotes?.customers?.company_name || "").toLowerCase().includes(q) ||
        (j.stage || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [jobs, filter, search]);

  // Group by stage
  const grouped = useMemo(() => {
    const stageOrder = ["Artwork", "Sourcing", "Ordered", "Received", "Staged", "Printing", "Pressing", "Finishing", "Dispatch", "Billing", "Incoming", "Paid"];
    const groups: Record<string, any[]> = {};
    for (const j of filtered) {
      const s = j.stage || "Incoming";
      if (!groups[s]) groups[s] = [];
      groups[s].push(j);
    }
    return stageOrder.filter(s => groups[s]?.length).map(s => ({ stage: s, jobs: groups[s] }));
  }, [filtered]);

  return (
    <div className="fixed inset-0 z-40 flex" onClick={onClose}>
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />

      {/* Side panel */}
      <div
        className="ml-auto h-full w-full max-w-md bg-white dark:bg-slate-950 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col relative animate-in slide-in-from-right duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="border-b border-slate-200 dark:border-slate-800 p-4 md:p-5 bg-gradient-to-br from-orange-500/5 to-transparent">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-xl font-black uppercase italic tracking-tighter text-black dark:text-white leading-none">Add From Jobs</h2>
              <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 mt-1.5">Drag onto calendar · or click to schedule</p>
            </div>
            <button onClick={onClose}
              className="text-slate-400 hover:text-black dark:hover:text-white text-xs font-black uppercase tracking-widest px-2 py-1">
              Close ✕
            </button>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-1.5 mb-3">
            {[
              { id: "next", label: "Next Action" },
              { id: "all",  label: "All Stages" },
              { id: "due",  label: "Due ≤ 7d" },
            ].map(t => (
              <button key={t.id}
                onClick={() => setFilter(t.id as any)}
                className={`flex-1 px-3 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${
                  filter === t.id
                    ? "bg-orange-500 text-white border-orange-500"
                    : "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Search */}
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by customer, job#, stage…"
            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-xs font-medium outline-none focus:border-orange-500"
          />
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 md:p-4 space-y-5">
          {grouped.length === 0 ? (
            <div className="text-center py-16 text-[10px] tracking-widest font-bold text-slate-300 dark:text-slate-700 uppercase">
              No jobs match
            </div>
          ) : grouped.map(({ stage, jobs: stageJobs }) => {
            const cls = STAGE_COLORS[stage] || STAGE_COLORS.Incoming;
            return (
              <div key={stage}>
                <div className="flex items-center gap-2 mb-2 px-1">
                  <div className={`w-2 h-2 rounded-full ${cls.chip}`}></div>
                  <div className={`text-[9px] font-black uppercase tracking-[0.3em] ${cls.text}`}>{stage}</div>
                  <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800"></div>
                  <div className="text-[9px] font-black text-slate-400">{stageJobs.length}</div>
                </div>
                <div className="space-y-2">
                  {stageJobs.map((job: any) => (
                    <JobPickerCard key={job.id} job={job} onClick={() => onClickJob(job)} onDragStart={() => onDragStart(job)} onDragEnd={onDragEnd} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer hint */}
        <div className="border-t border-slate-200 dark:border-slate-800 p-3 bg-slate-50 dark:bg-slate-900/50 text-center">
          <div className="text-[8px] font-black uppercase tracking-[0.3em] text-slate-400">
            ⊕ Drag a card onto the timeline · or click for details
          </div>
        </div>
      </div>
    </div>
  );
}

function JobPickerCard({ job, onClick, onDragStart, onDragEnd }: {
  job: any;
  onClick: () => void;
  onDragStart: () => void;
  onDragEnd: () => void;
}) {
  const cls = STAGE_COLORS[job.stage] || STAGE_COLORS.Incoming;
  const verb = STAGE_VERB[job.stage] || job.stage;
  const customer = job.quotes?.customers?.company_name || job.title || `#${job.job_number}`;
  const items = summarizeItems(job.quotes?.quote_items);

  // Due date pill
  let dueLabel = "";
  let dueClass = "text-slate-400";
  if (job.due_date) {
    const due = new Date(job.due_date + "T12:00:00");
    const today0 = new Date(); today0.setHours(0, 0, 0, 0);
    const days = Math.ceil((due.getTime() - today0.getTime()) / 86400000);
    if (days < 0) { dueLabel = `${-days}d late`; dueClass = "text-red-500"; }
    else if (days === 0) { dueLabel = "Today"; dueClass = "text-amber-500"; }
    else if (days <= 3) { dueLabel = `${days}d`; dueClass = "text-amber-500"; }
    else if (days <= 7) { dueLabel = `${days}d`; dueClass = "text-emerald-500"; }
    else { dueLabel = `${days}d`; dueClass = "text-slate-400"; }
  }

  return (
    <div
      draggable
      onDragStart={(e) => {
        // Required for Firefox to register the drag
        e.dataTransfer.setData("text/plain", String(job.id));
        e.dataTransfer.effectAllowed = "copy";
        onDragStart();
      }}
      onDragEnd={onDragEnd}
      onClick={onClick}
      className={`relative rounded-xl ${cls.bg} border border-slate-200/50 dark:border-slate-800 hover:ring-2 ${cls.ring} cursor-grab active:cursor-grabbing transition-all p-3 pl-4 group`}
      title="Drag to schedule, click for details"
    >
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${cls.chip} rounded-l-xl`}></div>

      {/* Drag handle indicator (visible on hover) */}
      <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 text-[10px] font-black tracking-widest pointer-events-none">⋮⋮</div>

      <div className="flex items-start justify-between gap-2 mb-1">
        <div className={`text-[8px] font-black uppercase tracking-[0.3em] ${cls.text}`}>{verb}</div>
        <div className="flex items-center gap-2 text-[8px] font-black tracking-widest">
          <span className="text-slate-400">#{job.job_number}</span>
          {dueLabel && <span className={dueClass}>· {dueLabel}</span>}
        </div>
      </div>

      <div className="text-[13px] font-black tracking-tight text-black dark:text-white leading-tight mb-1">
        {customer}
      </div>

      {items && (
        <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 leading-tight">
          {items}
        </div>
      )}

      {job.title && customer !== job.title && (
        <div className="text-[9px] text-slate-400 dark:text-slate-500 mt-1 italic truncate">
          {job.title}
        </div>
      )}
    </div>
  );
}

// ─── SCHEDULE JOB MODAL (click → detailed scheduling) ────────────────────────────
function ScheduleJobModal({ job, defaultDate, onClose, onSchedule }: {
  job: any;
  defaultDate: string;
  onClose: () => void;
  onSchedule: (opts: { date: string; time: string | null; duration: number; titleOverride?: string; notes?: string; energy?: string | null; priority?: string }) => Promise<void>;
}) {
  const cls = STAGE_COLORS[job.stage] || STAGE_COLORS.Incoming;
  const autoTitle = useMemo(() => buildJobTaskTitle(job), [job]);

  const [title, setTitle] = useState(autoTitle);
  const [date, setDate] = useState(defaultDate);
  const [time, setTime] = useState("09:00");
  const [unscheduled, setUnscheduled] = useState(false);
  const [duration, setDuration] = useState(60);
  const [notes, setNotes] = useState("");
  const [energy, setEnergy] = useState<string | null>(null);
  const [priority, setPriority] = useState("normal");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await onSchedule({
        date,
        time: unscheduled ? null : (time ? `${time}:00` : null),
        duration,
        titleOverride: title !== autoTitle ? title : undefined,
        notes: notes || undefined,
        energy,
        priority,
      });
    } finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={onClose}>
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 shadow-2xl" onClick={e => e.stopPropagation()}>

        {/* Job context header */}
        <div className={`relative ${cls.bg} rounded-xl p-4 mb-5 border border-slate-200/50 dark:border-slate-800`}>
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${cls.chip} rounded-l-xl`}></div>
          <div className="pl-2">
            <div className={`text-[8px] font-black uppercase tracking-[0.3em] ${cls.text} mb-1`}>{job.stage} · #{job.job_number}</div>
            <div className="text-base font-black tracking-tight text-black dark:text-white">{job.quotes?.customers?.company_name || job.title}</div>
            {summarizeItems(job.quotes?.quote_items, 60) && (
              <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mt-1">{summarizeItems(job.quotes?.quote_items, 60)}</div>
            )}
          </div>
        </div>

        <h2 className="text-lg font-black uppercase italic tracking-tighter text-black dark:text-white mb-4">Schedule Task</h2>

        <div className="space-y-4">
          <Field label="Task Title">
            <input value={title} onChange={e => setTitle(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-orange-500" />
            {title !== autoTitle && (
              <button onClick={() => setTitle(autoTitle)} className="text-[9px] text-slate-400 hover:text-orange-500 mt-1 font-black uppercase tracking-widest">↺ Reset to auto</button>
            )}
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Date">
              <input type="date" value={date} onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-orange-500" />
            </Field>
            <Field label={unscheduled ? "Time (skipped)" : "Time"}>
              <input type="time" value={time} onChange={e => setTime(e.target.value)} disabled={unscheduled}
                className={`w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-orange-500 ${unscheduled ? "opacity-40" : ""}`} />
            </Field>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={unscheduled} onChange={e => setUnscheduled(e.target.checked)} className="w-4 h-4 accent-orange-500" />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Unscheduled (add to pool)</span>
          </label>

          <Field label="Duration (minutes)">
            <div className="flex gap-1.5">
              {[15, 30, 60, 90, 120].map(d => (
                <button key={d} onClick={() => setDuration(d)}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-all ${
                    duration === d ? "bg-orange-500 text-white border-orange-500" : "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500"
                  }`}>{d < 60 ? `${d}m` : `${d / 60}h`}</button>
              ))}
              <input type="number" min={5} step={5} value={duration} onChange={e => setDuration(parseInt(e.target.value) || 60)}
                className="w-16 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2 py-2 text-xs font-black text-center outline-none focus:border-orange-500" />
            </div>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Priority">
              <div className="flex gap-1">
                {PRIORITIES.map(p => (
                  <button key={p.id} onClick={() => setPriority(p.id)}
                    className={`flex-1 px-2 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${
                      priority === p.id ? `${p.color} border-current` : "text-slate-400 border-slate-200 dark:border-slate-800"
                    }`}>{p.label}</button>
                ))}
              </div>
            </Field>
            <Field label="Energy">
              <div className="flex gap-1">
                {ENERGY_LEVELS.map(e => (
                  <button key={e.id} onClick={() => setEnergy(energy === e.id ? null : e.id)}
                    className={`flex-1 px-2 py-2 rounded-lg text-sm font-black border transition-all ${
                      energy === e.id ? "bg-amber-500/10 text-amber-500 border-amber-500/40" : "border-slate-200 dark:border-slate-800"
                    }`} title={e.label}>{e.icon}</button>
                ))}
              </div>
            </Field>
          </div>

          <Field label="Notes (optional)">
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2}
              placeholder="Reminders for yourself…"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-medium outline-none focus:border-orange-500 resize-none" />
          </Field>
        </div>

        <div className="flex gap-2 mt-6 pt-5 border-t border-slate-200 dark:border-slate-800">
          <button onClick={onClose} disabled={saving} className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">Cancel</button>
          <div className="flex-1"></div>
          <button onClick={submit} disabled={saving} className="px-5 py-2.5 rounded-xl bg-orange-500 text-white text-[10px] font-black uppercase tracking-widest hover:bg-orange-400 disabled:opacity-50">
            {saving ? "Scheduling…" : "Schedule Task"}
          </button>
        </div>

        <p className="text-[8px] text-slate-400 dark:text-slate-500 mt-3 text-center leading-relaxed">
          Creates a row in your day planner and a synced task on the production board.
        </p>
      </div>
    </div>
  );
}
